"""Regression checks for the merged planner, CLI, conversion and validation contracts."""

import shutil
import sys
from copy import deepcopy
from contextlib import contextmanager

import libsumo
import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.solution import (
    CommonRoadSolutionReader,
    CostFunction,
    PlanningProblemSolution,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.planning.planning_problem import PlanningProblem, PlanningProblemSet
from commonroad.scenario.lanelet import Lanelet
from commonroad.scenario.obstacle import ObstacleType, StaticObstacle
from commonroad.scenario.scenario import Scenario
from commonroad.scenario.state import CustomState, InitialState, KSState
from commonroad.scenario.trajectory import Trajectory

import planner.__main__ as cli
import planner.runtime.execution as execution
from planner.__main__ import main
from planner.common.scenarios import (
    all_scenario_iterator,
    scenario_iterator_interactive,
    scenario_iterator_non_interactive,
)
from planner.runtime.execution import (
    motion_planner,
    run_motion_planner_interactive,
    run_motion_planner_non_interactive,
)
from planner.runtime.submission import DEFAULT_SUBMISSION
from legacy_scenarios import introductory_scenarios
from planner.spec import PlannerSpec, smp_spec
from simulation.planner_adapter import PlannerAdapter
from simulation.simulations import SimulationSettings, simulate_with_planner
from simulation.solution_check import CollisionException, valid_solution
from test_simulation import DEMOS, StraightPlanner


class DirectPlanner(StraightPlanner):
    def __init__(self):
        self.calls = []

    def plan(self, scenario, problem):
        self.calls.append(problem.initial_state.time_step)
        states = []
        for _ in range(4):
            state = super().plan(scenario, problem).state_list[0]
            states.append(state)
            problem.initial_state.position = deepcopy(state.position)
            problem.initial_state.time_step = state.time_step
        return Trajectory(states[0].time_step, states)


@pytest.fixture
def select_factory(monkeypatch):
    def select(factory):
        @contextmanager
        def load(directory):
            assert directory == DEFAULT_SUBMISSION
            yield factory()

        for module in ("planner.runtime.execution", "simulation.simulations"):
            monkeypatch.setattr(f"{module}.load_submission", load)

    return select


def test_direct_planner_replanning_and_original_inputs():
    scenario, problems = CommonRoadFileReader(str(DEMOS / "DEU_Essen-7_3_I-1.xml")).open()
    planner = DirectPlanner()
    _, solution = run_motion_planner_interactive(
        planner,
        scenario,
        problems,
        settings=SimulationSettings(simulation_steps=4, replanning_interval=2),
    )
    assert planner.calls == [0, 2]
    assert [
        s.time_step for s in solution.planning_problem_solutions[0].trajectory.state_list
    ] == list(range(5))
    assert all(p.initial_state.time_step == 0 for p in problems.planning_problem_dict.values())
    assert not libsumo.isLoaded()


@pytest.mark.parametrize("entry", ["simulation", "non_interactive"])
def test_factory_entry_points_use_profile(select_factory, tmp_path, entry):
    path = DEMOS / "DEU_Essen-7_3_I-1.xml"
    planner = DirectPlanner()
    settings = SimulationSettings.for_vehicle(
        VehicleType.BMW_320i, simulation_steps=4, replanning_interval=2
    )
    spec = PlannerSpec(planner, settings=settings, vehicle_type=VehicleType.BMW_320i)
    select_factory(lambda: spec)
    if entry == "simulation":
        _, _, egos = simulate_with_planner(path)
        ego = next(iter(egos.values()))
        assert ego.obstacle_shape.length == settings.ego_veh_length
        assert ego.obstacle_shape.width == settings.ego_veh_width
        assert ego.prediction.final_time_step == 4
    else:
        scenario, problems = CommonRoadFileReader(str(path)).open()
        solution = motion_planner(scenario, tmp_path, problems)
        exported = solution.planning_problem_solutions[0]
        assert exported.vehicle_type == VehicleType.BMW_320i
        assert exported.vehicle_model == VehicleModel.KS
        assert exported.cost_function == CostFunction.SM1
        assert [s.time_step for s in exported.trajectory.state_list] == list(range(5))
    assert planner.calls == ([0] if entry == "non_interactive" else [0, 2])
    assert not libsumo.isLoaded()


def test_factory_settings_overrides_are_validated(select_factory, tmp_path):
    select_factory(smp_spec)
    with pytest.raises(ValueError, match="requires KS/BMW_320i"):
        simulate_with_planner(
            DEMOS / "DEU_Essen-7_3_I-1.xml",
            tmp_path,
            settings=SimulationSettings(replanning_interval=1),
        )
    assert not libsumo.isLoaded()


def test_non_interactive_planner_sees_recorded_predictions():
    scenario, problems = CommonRoadFileReader(str(DEMOS / "DEU_Essen-7_3_I-1.xml")).open()
    seen = []

    class ObservingPlanner(StraightPlanner):
        def plan(self, observation, problem):
            seen.append(
                any(
                    o.prediction and o.prediction.final_time_step > problem.initial_state.time_step
                    for o in observation.dynamic_obstacles
                )
            )
            return super().plan(observation, problem)

    solution = run_motion_planner_non_interactive(ObservingPlanner(), scenario, problems)
    assert seen and all(seen)
    assert [s.time_step for s in solution.planning_problem_solutions[0].trajectory.state_list] == [
        0,
        1,
    ]


def test_restored_static_obstacles_are_visible_and_isolated():
    original, problems = CommonRoadFileReader(str(introductory_scenarios()[2])).open()
    problem = next(iter(problems.planning_problem_dict.values()))
    scenario = deepcopy(original)
    scenario.remove_obstacle(list(scenario.static_obstacles))  # SUMO omits fixed geometry.
    obstacle = original.static_obstacles[0]
    position = obstacle.initial_state.position.copy()

    class Planner(StraightPlanner):
        def plan(self, observation, current):
            observed = observation.obstacle_by_id(obstacle.obstacle_id)
            np.testing.assert_array_equal(observed.initial_state.position, position)
            observed.initial_state.position += 100.0
            return super().plan(observation, current)

    adapter = PlannerAdapter(Planner(), static_obstacles=original.static_obstacles)
    adapter.plan(scenario, problem)
    adapter.plan(scenario, problem)
    assert not scenario.static_obstacles
    np.testing.assert_array_equal(obstacle.initial_state.position, position)


@pytest.mark.parametrize("explicit_submission", [False, True])
def test_cli_benchmark_settings_and_scenario_filter(monkeypatch, tmp_path, explicit_submission):
    scenarios = tmp_path / "scenarios"
    scenarios.mkdir()
    for path in (introductory_scenarios()[0], DEMOS / "DEU_Hennigsdorf-16_6_T-1.xml"):
        shutil.copy2(path, scenarios / path.name)
    (scenarios / "solution.xml").write_text("<CommonRoadSolution/>")
    assert len(list(all_scenario_iterator(scenarios))) == 2
    assert len(list(scenario_iterator_interactive(scenarios))) == 1
    assert len(list(scenario_iterator_non_interactive(scenarios))) == 1
    submission = tmp_path / "my_submission"
    submission.mkdir()
    (submission / "student_planner.py").write_text(
        "from dataclasses import replace\n"
        "from commonroad.common.solution import CostFunction\n"
        "from planner.spec import smp_spec\n\n"
        "def create_planner():\n"
        "    spec = smp_spec()\n"
        "    spec.settings = replace(spec.settings, simulation_steps=3, random_seed=999)\n"
        "    spec.cost_function = CostFunction.JB1\n"
        "    return spec\n"
    )
    monkeypatch.setattr(cli, "DEFAULT_SUBMISSION", submission)
    observed = []
    run_spec = execution.run_spec

    def record_settings(path, spec):
        observed.append((spec.settings, spec.cost_function))
        return run_spec(path, spec)

    monkeypatch.setattr(execution, "run_spec", record_settings)
    output = tmp_path / "solutions"
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "planner",
            "--scenarios",
            str(scenarios),
            "--solutions",
            str(output),
        ]
        + (["--submission", str(submission)] if explicit_submission else []),
    )
    assert main() == 0
    assert len(observed) == 1
    settings, cost_function = observed[0]
    assert settings.simulation_steps == 200
    assert settings.random_seed == 1234
    assert settings.replanning_interval == 5
    assert cost_function == CostFunction.SM1
    files = list(output.glob("*/solution.xml"))
    assert len(files) == 1
    for path in files:
        result = CommonRoadSolutionReader.open(str(path))
        simulated, problems = CommonRoadFileReader(str(path.with_name("scenario.xml"))).open()
        assert path.with_name("metadata.json").is_file()
        assert valid_solution(simulated, problems, result)[0]
        assert result.planning_problem_solutions[0].trajectory.initial_time_step == 0
        assert result.planning_problem_solutions[0].vehicle_type == VehicleType.BMW_320i
        assert result.planning_problem_solutions[0].cost_function == CostFunction.SM1
    assert not libsumo.isLoaded()


def test_cli_reports_no_interactive_scenarios(monkeypatch, tmp_path, capsys):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "planner",
            "--scenarios",
            str(DEMOS / "DEU_Hennigsdorf-16_6_T-1.xml"),
            "--solutions",
            str(tmp_path),
        ],
    )
    with pytest.raises(SystemExit) as error:
        main()
    assert error.value.code == 2
    assert "No interactive scenarios found" in capsys.readouterr().err


def test_validation_keeps_collisions_after_goal_in_scope():
    scenario = Scenario(dt=1.0)
    scenario.add_objects(
        Lanelet(
            np.array([[-20.0, 3.0], [60.0, 3.0]]),
            np.array([[-20.0, 0.0], [60.0, 0.0]]),
            np.array([[-20.0, -3.0], [60.0, -3.0]]),
            lanelet_id=1,
        )
    )
    initial = InitialState(
        position=np.array([0.0, 0.0]),
        orientation=0.0,
        velocity=1.0,
        acceleration=0.0,
        yaw_rate=0.0,
        slip_angle=0.0,
        time_step=0,
    )
    goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(2.0, 2.0, center=np.array([3.0, 0.0])), time_step=Interval(0, 30)
            )
        ]
    )
    problems = PlanningProblemSet([PlanningProblem(100, initial, goal)])
    states = [
        KSState(
            position=np.array([float(t), 0.0]),
            velocity=1.0,
            orientation=0.0,
            steering_angle=0.0,
            time_step=t,
        )
        for t in range(21)
    ]
    solution = Solution(
        scenario.scenario_id,
        [
            PlanningProblemSolution(
                100,
                VehicleModel.KS,
                VehicleType.FORD_ESCORT,
                CostFunction.TR1,
                Trajectory(0, states),
            )
        ],
    )
    assert valid_solution(scenario, problems, solution)[0]
    scenario.add_objects(
        StaticObstacle(
            200,
            ObstacleType.CAR,
            Rectangle(1.0, 1.0),
            InitialState(position=np.array([15.0, 0.0]), orientation=0.0, time_step=0),
        )
    )
    with pytest.raises(CollisionException):
        valid_solution(scenario, problems, solution)
