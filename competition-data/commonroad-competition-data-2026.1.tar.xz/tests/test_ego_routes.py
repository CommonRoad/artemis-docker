"""Exact valid ego commands must survive a short intermediate route edge."""

from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

import libsumo
import numpy as np
import pytest
import sumolib
from commonroad.scenario.state import KSState
from commonroad.scenario.trajectory import Trajectory
from commonroad.geometry.shape import Rectangle
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType
from commonroad_sumo.sumolib.sumo_project import SumoFileType

from planner.common.scenarios import ASSETS
from planner.runtime.execution import run_spec
from planner.spec import reactive_spec, smp_spec
from simulation.ego_routes import EgoRoutePreloader, _EgoRouteMatcher
from simulation.interactive import InteractiveSimulation
from simulation.planner_adapter import PlannerAdapter
from simulation.route_matching import FullGuideMapMatcher
from simulation.traffic import preserve_vehicle_dimensions
from test_route_matching import _network, _states
from test_interactive_sync import _initial, _straight_case, _StraightPlanner


CASES = json.loads((Path(__file__).parent / "fixtures/runtime/ego_short_edges.json").read_text())


class _ReplayCommands:
    def __init__(self, case):
        self.states = [
            KSState(**{**s, "position": np.array(s["position"])}) for s in case["states"][1:]
        ]
        self.planning_steps = case["planning_steps"]

    def plan(self, scenario, problem):
        step = problem.initial_state.time_step
        end = next((s for s in self.planning_steps if s > step), self.states[-1].time_step)
        states = [deepcopy(s) for s in self.states if step < s.time_step <= end]
        return Trajectory(step + 1, states)


@pytest.mark.parametrize("case", CASES, ids=lambda case: case["profile"])
@pytest.mark.parametrize("preload", [False, True], ids=["defect-control", "legal-continuation"])
def test_real_short_edge_preserves_exact_valid_commands(case, preload, monkeypatch):
    path = ASSETS / "scenarios/public" / (case["benchmark_id"] + ".xml")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == case["scenario_sha256"]
    spec = smp_spec() if case["profile"] == "search" else reactive_spec()
    spec.planner = _ReplayCommands(case)
    if not preload:
        monkeypatch.setattr(EgoRoutePreloader, "prepare", lambda *args: None)
        with pytest.raises(
            RuntimeError, match=f"SUMO actor 30459 does not match state {case['failure_step']}"
        ):
            run_spec(path, spec)
        return
    assignments = []
    original_set_route = libsumo.vehicle.setRoute

    def set_route(identifier, edges):
        assignments.append((identifier, libsumo.vehicle.getLaneID(identifier), list(edges)))
        return original_set_route(identifier, edges)

    monkeypatch.setattr(libsumo.vehicle, "setRoute", set_route)
    result = run_spec(path, spec)
    assert result.valid
    assert np.isfinite(result.cost)
    executed = result.solution.planning_problem_solutions[0].trajectory.state_list
    assert [state.time_step for state in executed] == [s["time_step"] for s in case["states"]]
    for actual, expected in zip(executed, case["states"]):
        np.testing.assert_allclose(actual.position, expected["position"], rtol=0, atol=1e-12)
        assert actual.velocity == pytest.approx(expected["velocity"], abs=1e-12)
        assert actual.orientation == pytest.approx(expected["orientation"], abs=1e-12)
    assert ("30459", ":35_8_1", ["777", "518", "329"]) in assignments


def test_actual_lane_anchor_rejects_closer_disconnected_road(tmp_path):
    net = _network(
        tmp_path,
        [
            ("nearby", "a", "b", [(0, 0), (20, 0)], None),
            ("actual", "c", "d", [(0, 0.8), (20, 0.8)], None),
        ],
        [],
    )
    states = _states([(2, 0), (4, 0), (6, 0)])
    assert FullGuideMapMatcher(net, "passenger", 5).match(states).edges == ("nearby",)
    matcher = _EgoRouteMatcher(net, "passenger", 5)
    assert matcher.match_from_lane(states, net.getLane("actual_0")).edges == ("actual",)


def test_distance_association_retains_forward_heading_and_class_permissions(tmp_path):
    net = _network(
        tmp_path,
        [
            ("cycleway", "a", "b", [(0, 0), (20, 0)], "bicycle"),
        ],
        [],
    )
    states = _states([(2, 0), (4, 0)])
    assert _EgoRouteMatcher(net, "bicycle", 5).match_from_lane(
        states, net.getLane("cycleway_0")
    ).edges == ("cycleway",)
    with pytest.raises(ValueError, match="forward route"):
        _EgoRouteMatcher(net, "passenger", 5).match_from_lane(states, net.getLane("cycleway_0"))
    for state in states:
        state.orientation = np.pi
    with pytest.raises(ValueError, match="forward route"):
        _EgoRouteMatcher(net, "bicycle", 5).match_from_lane(states, net.getLane("cycleway_0"))


def test_distance_ranking_reduces_external_lanes_before_comparing_edges(tmp_path):
    _network(
        tmp_path,
        [
            ("actual", "a", "b", [(0, 0.5), (10, 0.5)], None),
            ("other", "c", "d", [(0, 0.2), (10, 0.2)], None),
        ],
        [],
    )
    path = tmp_path / "network.net.xml"
    tree = ET.parse(path)
    angle = math.radians(20)
    intercept = 0.1 / math.cos(angle)
    ET.SubElement(
        tree.getroot().find("edge[@id='actual']"),
        "lane",
        id="actual_1",
        index="1",
        speed="13.89",
        length="10.6418",
        shape=f"0,{-5 * math.tan(angle) + intercept} 10,{5 * math.tan(angle) + intercept}",
    )
    tree.write(path)
    net = sumolib.net.readNet(str(path), withInternal=True)
    states = _states([(5, 0), (5.01, 0)])
    old = FullGuideMapMatcher(net, "passenger", 5)._candidates(states[0])
    assert old["actual"][1] == pytest.approx(0.5)
    matcher = _EgoRouteMatcher(net, "passenger", 5)
    matcher.match_from_lane(states, net.getLane("actual_0"))
    candidates = matcher._candidates(_states([(5, 0)])[0])
    assert candidates["actual"][1] == pytest.approx(0.1)
    assert candidates["actual"][0] < candidates["other"][0]


def test_direct_simulation_construction_initializes_ego_route_preload():
    scenario, problems = _straight_case()
    prepared = InteractiveSimulation.from_scenario(scenario, problems)
    preserve_vehicle_dimensions(
        scenario, prepared._sumo_project.get_file_path(SumoFileType.VEHICLE_ROUTES)
    )
    direct = InteractiveSimulation(scenario, problems, prepared._sumo_project)
    result = direct.run(PlannerAdapter(_StraightPlanner()), max_simulation_steps=2)
    assert result.ego_vehicles[10].state_at_time(2) is not None


def test_short_pending_prefix_preserves_existing_legal_route_tail(tmp_path):
    nodes, edges = tmp_path / "nodes.xml", tmp_path / "edges.xml"
    network, routes = tmp_path / "network.net.xml", tmp_path / "routes.rou.xml"
    nodes.write_text(
        '<nodes><node id="a" x="0" y="0"/><node id="b" x="100" y="0"/><node id="c" x="200" y="0"/></nodes>'
    )
    edges.write_text(
        '<edges><edge id="before" from="a" to="b" spreadType="center"/><edge id="after" from="b" to="c" spreadType="center"/></edges>'
    )
    subprocess.run(
        [
            "netconvert",
            "--node-files",
            str(nodes),
            "--edge-files",
            str(edges),
            "--offset.disable-normalization",
            "true",
            "--output-file",
            str(network),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    routes.write_text(
        '<routes><vType id="car" length="4.5" width="1.8"/><route id="r" edges="before after"/><vehicle id="7" type="car" route="r" depart="0" departPos="10" departSpeed="3"/></routes>'
    )
    libsumo.start(
        [
            "sumo",
            "--net-file",
            str(network),
            "--route-files",
            str(routes),
            "--step-length",
            "0.1",
            "--no-step-log",
            "true",
        ]
    )
    try:
        libsumo.simulationStep()
        ego = DynamicObstacle(
            7, ObstacleType.CAR, Rectangle(4.5, 1.8), _initial([7.75, 0], speed=3)
        )
        pending = _states([(8.05, 0)])
        EgoRoutePreloader(network).prepare(ego, pending)
        assert list(libsumo.vehicle.getRoute("7")) == ["before", "after"]
    finally:
        libsumo.close()
