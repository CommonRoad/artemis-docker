"""Historical cross-road bicycles are not lane-following SUMO driving tasks."""

import libsumo
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad_sumo.cr2sumo import ResimulationTrafficGeneratorConfig

from legacy_scenarios import FIXTURES
from simulation.conversion import StableMapConverter
from simulation.traffic import TerminalAwareTrafficGenerator


@pytest.mark.parametrize("name", ["RUS_Bicycle-11_1_I-1.xml", "RUS_Bicycle-7_1_I-1.xml",
                                  "RUS_Bicycle-4_2_I-1.xml"])
def test_unsupported_crossing_demo_is_explicitly_rejected(name, tmp_path):
    scenario, _ = CommonRoadFileReader(str(FIXTURES / name)).open()
    project = StableMapConverter(scenario).create_sumo_files(tmp_path)
    generator = TerminalAwareTrafficGenerator(config=ResimulationTrafficGeneratorConfig(
        extend_routes=True, extend_routes_upstream_junction=True,
        extend_routes_downstream_junction=True,
    ))
    with pytest.raises(ValueError, match="forward route"):
        generator.generate_traffic(scenario, project)
    assert not libsumo.isLoaded()
