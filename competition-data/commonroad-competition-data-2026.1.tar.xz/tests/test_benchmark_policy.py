"""Arrival windows and fixed traffic settings are benchmark rules."""

from contextlib import contextmanager
from copy import deepcopy
from types import SimpleNamespace

import numpy as np
import pytest
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.planning.planning_problem import PlanningProblem, PlanningProblemSet
from commonroad.scenario.state import CustomState, InitialState
from commonroad.scenario.trajectory import Trajectory

from planner.runtime import execution
from planner.spec import PlannerSpec
from simulation.simulations import SimulationSettings


@pytest.mark.parametrize("start,expected", [(1, True), (10, False)])
def test_early_goal_pass_is_accepted_by_arrival_window(start, expected):
    initial = InitialState(
        position=np.array([0.0, 0.0]),
        velocity=10.0,
        orientation=0.0,
        acceleration=0.0,
        yaw_rate=0.0,
        slip_angle=0.0,
        time_step=0,
    )
    goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(2.0, 3.0, np.array([5.0, 0.0])),
                time_step=Interval(start, 10),
            )
        ]
    )
    problem = PlanningProblem(1, initial, goal)
    states = []
    for step in range(11):
        state = deepcopy(initial)
        state.time_step = step
        state.position = np.array([float(step), 0.0])
        states.append(state)
    assert problem.goal_reached(Trajectory(0, states))[0] == expected
    assert not goal.is_reached(states[-1])


def test_submitted_factory_cannot_change_benchmark_traffic(monkeypatch):
    spec = PlannerSpec(
        object(),
        settings=SimulationSettings(
            simulation_steps=1,
            random_seed=9,
            replanning_interval=7,
        ),
    )

    @contextmanager
    def load(_):
        yield spec

    observed = []

    def run_spec(path, selected):
        observed.append(selected.settings)
        return SimpleNamespace(metadata={})

    monkeypatch.setattr(execution, "load_submission", load)
    monkeypatch.setattr(execution, "submission_metadata", lambda directory: {})
    monkeypatch.setattr(execution, "run_spec", run_spec)
    execution.run_submission("example.xml", "submission")
    assert observed[0].simulation_steps == 200
    assert observed[0].random_seed == 1234
    assert observed[0].replanning_interval == 7
