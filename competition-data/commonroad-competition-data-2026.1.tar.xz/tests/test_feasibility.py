"""Native dynamics checks on offline-normalized recorded Essen trajectories."""

from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.solution import (
    CostFunction,
    PlanningProblemSolution,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.geometry.shape import Rectangle
from commonroad.scenario.state import KSState, PMState
from commonroad.scenario.trajectory import Trajectory
from commonroad_dc.collision.collision_detection.pycrcc_collision_dispatch import (
    create_collision_object,
)
from commonroad_dc.feasibility.feasibility_checker import trajectory_feasibility
from commonroad_dc.feasibility.vehicle_dynamics import VehicleDynamics
from commonroad_dc.pycrcc import CollisionChecker

from planner.common.trajectory import validate_prefix
from planner.common.errors import InvalidPlan
from legacy_scenarios import reactive_scenarios
from simulation.solution_check import solution_feasible


@pytest.fixture
def braking_prefix():
    # Recorded Essen states at steps 35–40, in the normalized fixture map frame.
    records = json.loads(
        Path(__file__).with_name("fixtures").joinpath("essen_braking_prefix.json").read_text()
    )
    states = [KSState(**dict(state, position=np.array(state["position"]))) for state in records]
    return Trajectory(35, states)


def test_native_dynamics_preserve_inputs_and_timestamps(braking_prefix):
    original = deepcopy(braking_prefix)
    feasible, controls = trajectory_feasibility(
        braking_prefix, VehicleDynamics.KS(VehicleType.BMW_320i), 0.1
    )
    assert feasible
    assert [control.time_step for control in controls.state_list] == list(range(35, 40))
    for before, after in zip(original.state_list, braking_prefix.state_list):
        for attribute in before.attributes:
            np.testing.assert_array_equal(getattr(before, attribute), getattr(after, attribute))


def test_prefix_collision_check_uses_fixture_map_positions(braking_prefix):
    dynamics = VehicleDynamics.KS(VehicleType.BMW_320i)
    checker = CollisionChecker()
    validate_prefix(braking_prefix, 0.1, VehicleType.BMW_320i, dynamics.shape, checker)

    endpoint = braking_prefix.final_state
    checker.add_collision_object(
        create_collision_object(Rectangle(5.0, 2.0, endpoint.position, endpoint.orientation))
    )
    with pytest.raises(InvalidPlan, match="collides"):
        validate_prefix(braking_prefix, 0.1, VehicleType.BMW_320i, dynamics.shape, checker)


@pytest.mark.parametrize("fixture", ["braking_prefix", "scoring_search", "scoring_reactive"])
@pytest.mark.parametrize("invalid", [False, True])
def test_final_and_prefix_checks_agree(fixture, invalid):
    path = Path(__file__).with_name("fixtures") / f"essen_{fixture}.json"
    records = json.loads(path.read_text())
    states = [KSState(**dict(row, position=np.array(row["position"]))) for row in records]
    trajectory = Trajectory(states[0].time_step, states)
    scenario, problems = CommonRoadFileReader(str(reactive_scenarios()[0])).open()
    problem = next(iter(problems.planning_problem_dict.values()))
    if invalid:
        trajectory.final_state.position += np.array([0.5, 0.5])
    original = deepcopy(trajectory)
    solution = Solution(
        scenario.scenario_id,
        [
            PlanningProblemSolution(
                problem.planning_problem_id,
                VehicleModel.KS,
                VehicleType.BMW_320i,
                CostFunction.SM1,
                trajectory,
            )
        ],
    )
    feasible, controls, returned = solution_feasible(solution, 0.1, problems)[
        problem.planning_problem_id
    ]
    assert bool(feasible) == (not invalid)
    assert controls.initial_time_step == trajectory.initial_time_step
    assert returned is trajectory
    for before, after in zip(original.state_list, returned.state_list):
        for attribute in before.attributes:
            np.testing.assert_array_equal(getattr(before, attribute), getattr(after, attribute))

    dynamics = VehicleDynamics.KS(VehicleType.BMW_320i)
    if invalid:
        with pytest.raises(InvalidPlan, match="not dynamically feasible"):
            validate_prefix(
                trajectory, 0.1, VehicleType.BMW_320i, dynamics.shape, CollisionChecker()
            )
    else:
        validate_prefix(
            trajectory, 0.1, VehicleType.BMW_320i, dynamics.shape, CollisionChecker()
        )

    for before, after in zip(original.state_list, trajectory.state_list):
        for attribute in before.attributes:
            np.testing.assert_array_equal(getattr(before, attribute), getattr(after, attribute))


def test_point_mass_trajectories_use_native_checker():
    trajectory = Trajectory(
        10,
        [
            PMState(
                position=np.array([25.0 + 0.5 * step, -40.0 + 0.1 * step]),
                velocity=5.0,
                velocity_y=1.0,
                time_step=10 + step,
            )
            for step in range(3)
        ],
    )
    feasible, controls = trajectory_feasibility(
        trajectory, VehicleDynamics.PM(VehicleType.BMW_320i), 0.1
    )
    assert feasible
    assert [control.time_step for control in controls.state_list] == [10, 11]
