"""Route positions retain intended precision and use the selected lane's length."""

from types import SimpleNamespace
import xml.etree.ElementTree as ET

import numpy as np
import pytest
from unittest.mock import Mock
from commonroad_sumo.cr2sumo import UnsafeResimulationTrafficGenerator

from simulation.traffic import TerminalAwareTrafficGenerator, preserve_route_positions
import simulation.traffic as traffic_module


@pytest.mark.parametrize("extend_routes", [True, False])
@pytest.mark.parametrize("declared_geometry_ratio", [1.0, 1.75])
def test_positions_are_restored_on_the_selected_lane(tmp_path, extend_routes, declared_geometry_ratio):
    length = 106.558121234567
    network = tmp_path / "network.net.xml"
    network.write_text(f'''<net version="1.20">
      <edge id="road" from="start" to="end">
        <lane id="road_0" index="0" length="110.123456789012" speed="13.89" shape="0,0 110.123456789012,0"/>
        <lane id="road_1" index="1" length="{length}" speed="13.89" shape="0,3 {length / declared_geometry_ratio},3"/>
      </edge>
      <junction id="start" type="priority" x="0" y="0" incLanes="" intLanes=""/>
      <junction id="end" type="priority" x="{length}" y="0" incLanes="road_0 road_1" intLanes=""/>
    </net>''')
    routes = tmp_path / "routes.rou.xml"
    routes.write_text('''<routes><vehicle id="7" type="car" depart="0" departLane="1"
        departPos="10.12" arrivalLane="1" arrivalPos="106.56"><route edges="road"/></vehicle></routes>''')
    initial = SimpleNamespace(position=np.array([10.123456789012, 3.]))
    final = SimpleNamespace(position=np.array([40.123456789012, 3.]))
    actor = SimpleNamespace(obstacle_id=7, initial_state=initial,
                            prediction=SimpleNamespace(trajectory=SimpleNamespace(final_state=final)))
    scenario = SimpleNamespace(dynamic_obstacles=[actor])
    adjustments = preserve_route_positions(scenario, network, routes, extend_routes=extend_routes)
    vehicle = ET.parse(routes).getroot().find("vehicle")
    assert vehicle.find("route").get("edges") == "road"
    assert vehicle.get("departLane") == vehicle.get("arrivalLane") == "1"
    assert float(vehicle.get("departPos")) == pytest.approx(initial.position[0] * declared_geometry_ratio, abs=1e-12)
    expected = length - .001 if extend_routes else final.position[0] * declared_geometry_ratio
    assert float(vehicle.get("arrivalPos")) == pytest.approx(expected, abs=1e-12)
    assert 0 <= float(vehicle.get("arrivalPos")) < length
    assert {row["lane_id"] for row in adjustments} == {"road_1"}


def test_failed_generation_does_not_attempt_route_position_recovery(monkeypatch):
    monkeypatch.setattr(traffic_module.sumolib.net, "readNet", lambda *args, **kwargs: object())
    monkeypatch.setattr(UnsafeResimulationTrafficGenerator, "generate_traffic", lambda *args: False)
    recovery = Mock(side_effect=AssertionError("No route file exists after failed generation"))
    monkeypatch.setattr(traffic_module, "preserve_route_positions", recovery)
    project = SimpleNamespace(get_file_path=lambda kind: "missing-file")
    assert TerminalAwareTrafficGenerator().generate_traffic(object(), project) is False
    recovery.assert_not_called()
