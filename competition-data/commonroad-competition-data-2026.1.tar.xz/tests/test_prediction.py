"""Lane-following forecasts from current observations, with straight-line fallback."""

from copy import deepcopy

import numpy as np
import pytest
from commonroad.geometry.shape import Rectangle
from commonroad.prediction.prediction import TrajectoryPrediction
from commonroad.scenario.lanelet import Lanelet
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType, StaticObstacle
from commonroad.scenario.scenario import Scenario
from commonroad.scenario.state import InitialState, CustomState
from commonroad.scenario.trajectory import Trajectory

from planner.common.errors import IncompatibleState
from planner.common.prediction import predict_observations


def lanelet(path, lane_id=1, successors=(), width=4.0):
    path = np.asarray(path, dtype=float)
    tangents = np.gradient(path, axis=0)
    tangents /= np.linalg.norm(tangents, axis=1)[:, None]
    normals = np.column_stack((-tangents[:, 1], tangents[:, 0]))
    return Lanelet(
        path + width / 2 * normals,
        path,
        path - width / 2 * normals,
        lane_id,
        successor=list(successors),
    )


def actor(position, heading=0.0, speed=6.0, current=0, obstacle_id=100):
    return DynamicObstacle(
        obstacle_id,
        ObstacleType.CAR,
        Rectangle(4.0, 1.8),
        InitialState(
            position=np.array(position, dtype=float),
            orientation=heading,
            velocity=speed,
            acceleration=0.0,
            yaw_rate=0.0,
            slip_angle=0.0,
            time_step=current,
        ),
    )


def forecast(scenario, obstacle, horizon=20):
    scenario.add_objects(obstacle)
    return predict_observations(scenario, obstacle.initial_state.time_step, horizon).obstacle_by_id(
        obstacle.obstacle_id
    )


def assert_straight(predicted, observed, dt):
    direction = np.array([np.cos(observed.orientation), np.sin(observed.orientation)])
    for state in predicted.prediction.trajectory.state_list:
        np.testing.assert_allclose(
            state.position, observed.position + state.time_step * dt * observed.velocity * direction
        )
        assert state.orientation == observed.orientation
        assert state.velocity == observed.velocity


@pytest.mark.parametrize("origin", [np.zeros(2), np.array([450000.0, 6700000.0])])
def test_curve_follows_lane_at_constant_longitudinal_speed_without_lateral_snap(origin):
    radius, offset, angle = 30.0, 0.75, 0.2
    angles = np.linspace(0, 1.3, 131)
    path = np.column_stack((radius * np.sin(angles), radius * (1 - np.cos(angles))))
    scenario = Scenario(0.1)
    scenario.add_objects(lanelet(path + origin))
    position = origin + [
        (radius - offset) * np.sin(angle),
        radius - (radius - offset) * np.cos(angle),
    ]
    observed = actor(position, heading=angle, current=7)
    predicted = forecast(scenario, observed)
    np.testing.assert_array_equal(predicted.initial_state.position, position)
    assert predicted.initial_state.orientation == angle
    assert predicted.initial_state.time_step == 0
    assert [s.time_step for s in predicted.prediction.trajectory.state_list] == list(range(1, 21))
    for state in predicted.prediction.trajectory.state_list:
        future_angle = (
            angle + state.time_step * scenario.dt * observed.initial_state.velocity / radius
        )
        expected = origin + [
            (radius - offset) * np.sin(future_angle),
            radius - (radius - offset) * np.cos(future_angle),
        ]
        np.testing.assert_allclose(state.position, expected, atol=0.02, rtol=0)
        assert state.orientation == pytest.approx(future_angle, abs=0.02)
        assert state.velocity == observed.initial_state.velocity
    assert predicted.state_at_time(20).orientation > angle + 0.3
    np.testing.assert_array_equal(
        scenario.lanelet_network.lanelets[0].center_vertices, path + origin
    )
    assert observed.prediction is None
    assert observed.initial_state.time_step == 7


def test_unique_successor_is_followed_around_curve():
    scenario = Scenario(0.1)
    scenario.add_objects(lanelet([[0, 0], [5, 0], [10, 0]], successors=[2]))
    angles = np.linspace(0, np.pi / 2, 101)
    curve = np.column_stack((10 + 10 * np.sin(angles), 10 * (1 - np.cos(angles))))
    scenario.add_objects(lanelet(curve, lane_id=2))
    predicted = forecast(scenario, actor([8, 0], speed=5), horizon=20)
    end = predicted.state_at_time(20)
    np.testing.assert_allclose(
        end.position, [10 + 10 * np.sin(0.8), 10 * (1 - np.cos(0.8))], atol=0.03
    )
    assert end.orientation == pytest.approx(0.8, abs=0.03)


@pytest.mark.parametrize("fork", [False, True])
def test_lane_end_or_unknown_fork_continues_straight(fork):
    scenario = Scenario(0.1)
    successors = [2, 3] if fork else []
    scenario.add_objects(lanelet([[0, 0], [5, 0], [10, 0]], successors=successors))
    if fork:
        scenario.add_objects(lanelet([[10, 0], [15, 5], [20, 10]], lane_id=2))
        scenario.add_objects(lanelet([[10, 0], [15, -5], [20, -10]], lane_id=3))
    observed = actor([8, 0], speed=5)
    predicted = forecast(scenario, observed)
    assert_straight(predicted, observed.initial_state, scenario.dt)


@pytest.mark.parametrize("position,heading", [([5, 8], 0.3), ([5, 0], np.pi / 2), ([5, 0], np.pi)])
def test_off_lane_crossing_and_oncoming_actors_use_straight_fallback(position, heading):
    scenario = Scenario(0.1)
    scenario.add_objects(lanelet([[0, 0], [10, 0], [20, 0]]))
    observed = actor(position, heading=heading)
    assert_straight(forecast(scenario, observed), observed.initial_state, scenario.dt)


def test_overlapping_lanes_are_matched_by_heading():
    scenario = Scenario(0.1)
    scenario.add_objects(lanelet([[10, -10], [10, 0], [10, 10]], lane_id=1))
    scenario.add_objects(lanelet([[0, 0], [10, 0], [20, 0]], lane_id=2))
    observed = actor([10, 0])
    assert_straight(forecast(scenario, observed), observed.initial_state, scenario.dt)


def test_unprojectable_actor_uses_straight_fallback():
    scenario = Scenario(0.1)
    # Inside the lane polygon, but outside the CLCS default lateral projection domain.
    scenario.add_objects(lanelet([[0, 0], [10, 0], [20, 0]], width=60))
    observed = actor([5, 25], heading=0.1)
    assert_straight(forecast(scenario, observed), observed.initial_state, scenario.dt)


@pytest.mark.parametrize("degenerate", [False, True])
def test_repeated_centerline_vertices_are_supported_or_fall_back(degenerate):
    scenario = Scenario(0.1)
    lane = lanelet([[0, 0], [10, 0], [20, 0]])
    # Preserve a valid lane polygon while exercising unusable centerline geometry.
    lane.center_vertices = np.array(
        [[0.0, 0.0]] * 3 if degenerate else [[0.0, 0.0], [0.0, 0.0], [20.0, 0.0]]
    )
    scenario.add_objects(lane)
    observed = actor([5, 0], heading=0.1 if degenerate else 0.0)
    assert_straight(forecast(scenario, observed), observed.initial_state, scenario.dt)


def test_stationary_actor_keeps_position_and_heading_even_on_a_lane():
    scenario = Scenario(0.1)
    scenario.add_objects(lanelet([[0, 0], [10, 0], [20, 0]]))
    observed = actor([5, 0.75], heading=0.2, speed=0)
    predicted = forecast(scenario, observed)
    assert_straight(predicted, observed.initial_state, scenario.dt)


def test_current_observation_only_preserves_static_obstacles_and_input():
    scenario = Scenario(0.1)
    observed = actor([1, 0], current=6)
    states = [
        CustomState(position=np.array([2.0, 0.0]), orientation=0.0, velocity=6.0, time_step=7),
        CustomState(position=np.array([999.0, 0.0]), orientation=2.0, velocity=30.0, time_step=8),
    ]
    observed.prediction = TrajectoryPrediction(Trajectory(7, states), observed.obstacle_shape)
    scenario.add_objects(
        [
            observed,
            actor([0, 0], current=4, obstacle_id=101),
            actor([0, 0], current=9, obstacle_id=102),
            StaticObstacle(
                103, ObstacleType.PARKED_VEHICLE, Rectangle(4.0, 1.8), actor([30, 0]).initial_state
            ),
        ]
    )
    scenario.add_objects(lanelet([[0, 0], [10, 0], [20, 0]]))
    original = deepcopy(scenario)
    predicted = predict_observations(scenario, current=7, horizon=20)
    assert [o.obstacle_id for o in predicted.dynamic_obstacles] == [100]
    assert predicted.dt == scenario.dt
    assert len(predicted.static_obstacles) == 1
    np.testing.assert_array_equal(predicted.obstacle_by_id(103).initial_state.position, [30, 0])
    np.testing.assert_allclose(predicted.obstacle_by_id(100).state_at_time(20).position, [14, 0])
    np.testing.assert_array_equal(
        observed.state_at_time(8).position, original.obstacle_by_id(100).state_at_time(8).position
    )
    assert observed.initial_state.time_step == 6
    assert len(scenario.dynamic_obstacles) == 3


def test_invalid_observation_remains_an_explicit_error():
    scenario = Scenario(0.1)
    observed = actor([1, 0])
    observed.initial_state.velocity = -1.0
    scenario.add_objects(observed)
    with pytest.raises(IncompatibleState, match="unusable current state"):
        predict_observations(scenario, current=0, horizon=20)
