"""Valid straight runtime demos and retained historical converter fixtures."""

from pathlib import Path

FIXTURES = Path(__file__).parent / "fixtures" / "legacy"
RUNTIME = Path(__file__).parent / "fixtures" / "runtime"


def introductory_scenarios():
    return [
        RUNTIME / name
        for name in (
            "ZAM_RuntimeStraight-1_1_I-1.xml",
            "ZAM_RuntimeStraight-2_1_I-1.xml",
            "ZAM_RuntimeStraight-3_1_I-1.xml",
        )
    ]


def reactive_scenarios():
    return [FIXTURES / "demo" / "DEU_Essen-7_3_I-1.xml"]
