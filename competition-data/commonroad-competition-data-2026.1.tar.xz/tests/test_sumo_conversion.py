"""Isolate the mutable-edge sign boundary and preserve unrelated priority behavior."""

import numpy as np
import pytest
from commonroad.scenario.traffic_sign import TrafficSign, TrafficSignElement, TrafficSignIDGermany
from commonroad_sumo.cr2sumo.map_converter.traffic_sign import TrafficSignEncoder
from commonroad_sumo.sumolib.net import Edge, EdgeType, EdgeTypes, Lane, Node, NodeType

from simulation.conversion import StableTrafficSignEncoder


def graph(*, cycle=False, curved_branch=False):
    types = EdgeTypes({"road": EdgeType("road", speed=13.89, priority=3)})
    nodes = [Node(index, NodeType.PRIORITY, np.array([float(index), 0.0])) for index in range(5)]
    edges = []
    for index in range(4 if curved_branch else 3):
        edge = Edge(str(index), nodes[index], nodes[index + 1], type_id="road")
        shape = np.array([[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]])
        if curved_branch and index == 3:
            shape = np.array([[0.0, 0.0], [0.0, 0.1], [0.1, 0.1]])
        Lane(edge, speed=13.89, length=2.0, width=3.5, shape=shape)
        edges.append(edge)
    edges[0].add_outgoing(edges[1])
    edges[1].add_outgoing(edges[2])
    if cycle:
        edges[2].add_outgoing(edges[0])
    if curved_branch:
        edges[0].add_outgoing(edges[3])
    return types, edges


def sign(index, element_type, values=()):
    return TrafficSign(
        index,
        [TrafficSignElement(element_type, list(values))],
        set(),
        np.zeros(2),
    )


@pytest.mark.parametrize("cycle", [False, True])
def test_local_speed_sign_survives_an_upstream_speed_assignment(cycle):
    types, edges = graph(cycle=cycle)
    encoder = StableTrafficSignEncoder(types)
    encoder.apply(sign(1, TrafficSignIDGermany.MAX_SPEED, ["1.94"]), edges[1])
    encoder.apply(sign(2, TrafficSignIDGermany.MAX_SPEED, ["13.89"]), edges[0])
    encoder.encode()
    assert [edge.lanes[0].speed for edge in edges] == [13.89, 1.94, 1.94]


@pytest.mark.parametrize("cycle", [False, True])
def test_priority_curvature_and_cycle_behavior_matches_upstream(cycle):
    outcomes = []
    for encoder_type in (TrafficSignEncoder, StableTrafficSignEncoder):
        types, edges = graph(cycle=cycle, curved_branch=True)
        encoder = encoder_type(types)
        encoder.apply(sign(1, TrafficSignIDGermany.PRIORITY), edges[0])
        encoder.encode()
        outcomes.append(
            (
                [types.types[edge.type_id].priority for edge in edges],
                [edge.to_node.type for edge in edges],
                [edge.lanes[0].speed for edge in edges],
            )
        )
    assert outcomes[0] == outcomes[1]
    assert outcomes[1][0] == [4, 4, 4, 3]


def test_speed_and_priority_on_one_edge_preserve_both_values():
    types, edges = graph()
    encoder = StableTrafficSignEncoder(types)
    encoder.apply(sign(1, TrafficSignIDGermany.PRIORITY), edges[0])
    encoder.apply(sign(2, TrafficSignIDGermany.MAX_SPEED, ["1.94"]), edges[0])
    encoder.encode()
    assert [edge.lanes[0].speed for edge in edges] == [1.94, 1.94, 1.94]
    assert [types.types[edge.type_id].priority for edge in edges] == [4, 4, 4]


@pytest.mark.parametrize(
    ('filename', 'source_lane'),
    [
        ('DEU_MoellnCRC26E-2_14500_I-1.xml', '52058_0'),
        ('GRC_PeramaCRC26E-7_15300_I-1.xml', '66304_0'),
        ('DEU_EssenCRC26P-52_69240_I-1.xml', None),
        ('DEU_EssenCRC26P-60_19500_I-1.xml', None),
        ('DEU_MoellnCRC26E-11_64330_I-1.xml', None),
        ('HRV_PulaCRC26E-13_15400_I-1.xml', None),
        ('DEU_HennigsdorfCRC26E-9_13000_I-1.xml', None),
        ('DEU_ErlangenCRC26P-12_17300_I-1.xml', None),
    ],
)
def test_source_geometry_survives_junction_conversion(tmp_path, filename, source_lane):
    """Verify real lane chains, including internal via lanes, after conversion.

    The two representative outgoing lanes formerly jumped 2.897m/5.086m
    away from their preceding custom turn, giving SUMO a large lateral offset.
    """
    from pathlib import Path
    import xml.etree.ElementTree as ET
    from commonroad.common.file_reader import CommonRoadFileReader
    from commonroad_sumo.sumolib.sumo_project import SumoFileType
    from simulation.conversion import StableMapConverter

    assets = Path(__file__).resolve().parents[1] / 'planner/assets/scenarios/public'
    scenario, _ = CommonRoadFileReader(str(assets / filename)).open()
    converter = StableMapConverter(scenario)
    project = converter.create_sumo_files(tmp_path)
    assert project is not None
    net = ET.parse(project.get_file_path(SumoFileType.NET)).getroot()
    shapes = {
        lane.get('id'): np.array([
            [float(value) for value in point.split(',')]
            for point in lane.get('shape').split()
        ])
        for lane in net.findall('./edge/lane')
    }
    links = net.findall('connection')
    assert any(link.get('via') for link in links)
    for link in links:
        previous = f"{link.get('from')}_{link.get('fromLane')}"
        following = link.get('via') or f"{link.get('to')}_{link.get('toLane')}"
        assert previous in shapes and following in shapes
        # netconvert writes coordinates at centimetre precision.
        assert np.linalg.norm(shapes[previous][-1] - shapes[following][0]) < .015, (previous, following)
    if source_lane:
        source = np.asarray(converter.lanes[source_lane].shape)
        np.testing.assert_allclose(shapes[source_lane][[0, -1]], source[[0, -1]], atol=.0051)


def test_reference_geometry_keeps_lane_shapes_and_control_assignments():
    """Reference geometry must not mutate input lanes, signs or signals."""
    from pathlib import Path
    from copy import deepcopy
    from commonroad.common.file_reader import CommonRoadFileReader
    from commonroad_sumo.cr2sumo import CR2SumoMapConverter
    from simulation.conversion import StableMapConverter

    path = Path(__file__).resolve().parents[1] / 'planner/assets/scenarios/public/DEU_ErlangenCRC26P-12_17300_I-1.xml'
    scenario, _ = CommonRoadFileReader(str(path)).open()
    source_shapes = {lane.lanelet_id: lane.center_vertices.copy() for lane in scenario.lanelet_network.lanelets}
    baseline = StableMapConverter(deepcopy(scenario))
    baseline._create_sumo_edges_and_lanes = lambda: CR2SumoMapConverter._create_sumo_edges_and_lanes(baseline)
    baseline._convert_map()
    candidate = StableMapConverter(scenario)
    candidate._convert_map()
    assert candidate.new_edges.keys() == baseline.new_edges.keys()
    assert candidate.lanes.keys() == baseline.lanes.keys()
    for identifier, lane in candidate.lanes.items():
        np.testing.assert_array_equal(lane.shape, baseline.lanes[identifier].shape)
        assert lane.speed == baseline.lanes[identifier].speed
        assert lane.width == baseline.lanes[identifier].width
    for identifier, edge in candidate.new_edges.items():
        other = baseline.new_edges[identifier]
        assert (edge.from_node.id, edge.to_node.id, edge.type_id) == (other.from_node.id, other.to_node.id, other.type_id)
    for lane in scenario.lanelet_network.lanelets:
        np.testing.assert_array_equal(lane.center_vertices, source_shapes[lane.lanelet_id])


def test_connection_check_follows_split_internal_via_chain(tmp_path):
    from simulation.conversion import _connection_gaps

    path = tmp_path / 'network.net.xml'
    network = '''<net>
      <edge id="a"><lane id="a_0" shape="0,0 1,0"/></edge>
      <edge id=":j_0"><lane id=":j_0_0" shape="1,0 2,0"/></edge>
      <edge id=":j_1"><lane id=":j_1_0" shape="2,0 3,0"/></edge>
      <edge id="b"><lane id="b_0" shape="3,0 4,0"/></edge>
      <connection from="a" to="b" fromLane="0" toLane="0" via=":j_0_0"/>
      <connection from=":j_0" to="b" fromLane="0" toLane="0" via=":j_1_0"/>
      <connection from=":j_1" to="b" fromLane="0" toLane="0"/>
    </net>'''
    path.write_text(network)
    assert _connection_gaps(path) == []
    path.write_text(network.replace('shape="2,0 3,0"', 'shape="2,1 3,0"'))
    assert _connection_gaps(path) == [(('a', 'b', '0', '0'), 1.0)]
    path.write_text(network.replace('via=":j_1_0"', 'via=":missing_0"'))
    with pytest.raises(ValueError, match='missing lane'):
        _connection_gaps(path)


def test_traffic_only_helper_uses_the_same_converter(monkeypatch):
    from pathlib import Path
    from simulation import simulations
    from simulation.conversion import StableMapConverter, _connection_gaps
    from commonroad_sumo.sumolib.sumo_project import SumoFileType

    captured = []
    class RecordedConverter(StableMapConverter):
        def create_sumo_files(self, *args, **kwargs):
            project = super().create_sumo_files(*args, **kwargs)
            captured.append(_connection_gaps(project.get_file_path(SumoFileType.NET)))
            return project

    monkeypatch.setattr(simulations, 'StableMapConverter', RecordedConverter)
    source = Path(__file__).resolve().parents[1] / 'planner/assets/scenarios/public/DEU_MoellnCRC26E-2_14500_I-1.xml'
    result, _ = simulations.simulate_without_ego(source, num_of_steps=2)
    assert captured == [[]]
    assert result.dynamic_obstacles


def test_precise_conversion_rejects_small_physical_lane_gap(tmp_path):
    from simulation.conversion import _connection_gaps
    path = tmp_path / 'precise.net.xml'
    path.write_text('''<net>
      <edge id="a"><lane id="a_0" shape="0,0 1,0"/></edge>
      <edge id="b"><lane id="b_0" shape="1.00001,0 2,0"/></edge>
      <connection from="a" to="b" fromLane="0" toLane="0"/>
    </net>''')
    gaps = _connection_gaps(path)
    assert gaps[0][0] == ('a', 'b', '0', '0')
    assert gaps[0][1] == pytest.approx(1e-5)


def test_merged_node_serialization_is_independent_of_process_hash_seed():
    import json
    import os
    from pathlib import Path
    import subprocess
    import sys

    path = Path(__file__).resolve().parents[1] / 'planner/assets/scenarios/public/ARG_CarcaranaCRC26E-2_10100_I-1.xml'
    script = f'''
import json
from commonroad.common.file_reader import CommonRoadFileReader
from simulation.conversion import StableMapConverter
scenario, _ = CommonRoadFileReader({str(path)!r}).open()
converter = StableMapConverter(scenario)
converter._convert_map()
print(json.dumps([converter.new_nodes[i].to_xml_element().attrib for i in sorted(converter.new_nodes)], sort_keys=True))
'''
    outputs = []
    for seed in ('1', '7', '199'):
        environment = {**os.environ, 'PYTHONHASHSEED': seed}
        result = subprocess.run([sys.executable, '-c', script], env=environment, text=True, capture_output=True, check=True)
        outputs.append(json.loads(result.stdout))
    assert outputs[0] == outputs[1] == outputs[2]


def test_hennig_millimetre_gap_keeps_the_mapped_left_turn(tmp_path):
    """A 4 mm endpoint mismatch must not replace a 1.76 m curved interior."""
    from pathlib import Path
    import xml.etree.ElementTree as ET
    from commonroad.common.file_reader import CommonRoadFileReader
    from commonroad_sumo.sumolib.sumo_project import SumoFileType
    from simulation.conversion import StableMapConverter, _connection_gaps

    source = Path(__file__).resolve().parents[1] / 'planner/assets/scenarios/public/DEU_HennigsdorfCRC26E-9_13000_I-1.xml'
    scenario, _ = CommonRoadFileReader(str(source)).open()
    converter = StableMapConverter(scenario)
    project = converter.create_sumo_files(tmp_path)
    network = project.get_file_path(SumoFileType.NET)
    root = ET.parse(network).getroot()
    connection = next(c for c in root.findall('connection') if c.get('from') == '1755' and c.get('to') == '2047')
    lane = next(l for l in root.findall('./edge/lane') if l.get('id') == connection.get('via'))
    actual = np.array([[float(v) for v in point.split(',')] for point in lane.get('shape').split()])
    mapped = next(c.shape for c in converter._new_connections if c.from_lane.id == '1755_1' and c.to_lane.id == '2047_0')
    np.testing.assert_allclose(actual[1:-1], mapped[1:-1], atol=1e-11, rtol=0)
    assert converter.endpoint_stitches
    assert any(e['lane'] == lane.get('id') and e['gap_m'] < .01 for e in converter.endpoint_stitches)
    assert not _connection_gaps(network)


def test_endpoint_stitch_preserves_interior_and_external_geometry(tmp_path):
    import xml.etree.ElementTree as ET
    from simulation.conversion import _connection_gaps, _stitch_small_connection_gaps
    path = tmp_path / 'network.net.xml'
    path.write_text('''<net>
      <edge id="a"><lane id="a_0" shape="0,0 1,0" length="1"/></edge>
      <edge id=":j_0"><lane id=":j_0_0" shape="1.004,0 1.5,1 2.004,0" length="2.23" speed="5"/></edge>
      <edge id="b"><lane id="b_0" shape="2,0 3,0" length="1"/></edge>
      <connection from="a" to="b" fromLane="0" toLane="0" via=":j_0_0" state="m"/>
      <connection from=":j_0" to="b" fromLane="0" toLane="0" state="M"/>
    </net>''')
    before = ET.parse(path).getroot()
    edits = _stitch_small_connection_gaps(path)
    after = ET.parse(path).getroot()
    assert len(edits) == 2
    assert after.find("edge[@id='a']/lane").get('shape') == before.find("edge[@id='a']/lane").get('shape')
    assert after.find("edge[@id='b']/lane").get('shape') == before.find("edge[@id='b']/lane").get('shape')
    turn = after.find("edge[@id=':j_0']/lane")
    points = np.array([[float(v) for v in p.split(',')] for p in turn.get('shape').split()])
    np.testing.assert_array_equal(points, [[1., 0.], [1.5, 1.], [2., 0.]])
    assert [c.attrib for c in before.findall('connection')] == [c.attrib for c in after.findall('connection')]
    assert float(turn.get('length')) == pytest.approx(2 * np.sqrt(1.25))
    assert not _connection_gaps(path)
