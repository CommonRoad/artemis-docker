"""Reactive integration contracts beyond the shared execution and SMP checks."""

from copy import deepcopy

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.scenario.obstacle import ObstacleType, StaticObstacle
from commonroad.scenario.state import CustomState, InitialState
from commonroad_dc.collision.collision_detection.pycrcc_collision_dispatch import (
    create_collision_object,
)
from commonroad_rp.reactive_planner import ReactivePlanner

from planner.common.errors import InvalidPlan, NoPathFound
from planner.algorithms.reactive import ReactivePlannerAdapter
from legacy_scenarios import introductory_scenarios


@pytest.fixture
def example():
    scenario, problems = CommonRoadFileReader(str(introductory_scenarios()[0])).open()
    return scenario, next(iter(problems.planning_problem_dict.values()))


def test_continuous_state_nonzero_time_and_partial_goal(example):
    scenario, problem = example
    scenario.remove_obstacle(list(scenario.dynamic_obstacles))
    problem.initial_state.time_step = 10
    problem.initial_state.velocity += 0.37  # RP accepts speeds outside the primitive grid.
    adapter = ReactivePlannerAdapter()
    trajectory = adapter.plan(scenario, problem)
    assert [state.time_step for state in trajectory.state_list] == [11, 12, 13]
    assert not problem.goal.is_reached(
        trajectory.final_state
    )  # A rolling plan can stop before the goal.
    problem.goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(0.1, 0.1, center=trajectory.state_list[1].position),
                time_step=Interval(12, 12),
            )
        ]
    )
    adapter.reset()
    trajectory = adapter.plan(scenario, problem)
    assert [state.time_step for state in trajectory.state_list] == [11, 12]
    assert problem.goal.is_reached(trajectory.final_state)
    assert adapter.diagnostics[-1]["horizon_steps"] == 20
    problem.initial_state.time_step = 12
    with pytest.raises(NoPathFound, match="deadline"):
        adapter.plan(scenario, problem)


def test_replanning_restores_controls_and_refreshes_collision_checker(example, monkeypatch):
    scenario, problem = example
    adapter = ReactivePlannerAdapter()
    adapter.plan(scenario, problem)
    key = (str(scenario.scenario_id), problem.planning_problem_id)
    endpoint = adapter._endpoints[key]
    endpoint.steering_angle = 0.08
    endpoint.acceleration = 0.3
    for name in ("position", "orientation", "velocity", "time_step"):
        setattr(problem.initial_state, name, deepcopy(getattr(endpoint, name)))
    core = adapter._planners[key]
    old_checker = core.collision_checker
    marker = StaticObstacle(
        scenario.generate_object_id(),
        ObstacleType.CAR,
        Rectangle(0.1, 0.1),
        InitialState(position=endpoint.position.copy(), orientation=0.0, time_step=0),
    )
    assert not old_checker.collide(create_collision_object(marker))
    scenario.add_objects(marker)

    def inspect():
        assert core.x_0.time_step == 0
        assert core.x_0.steering_angle == 0.08
        assert core.x_0.acceleration == 0.3
        assert core.collision_checker is not old_checker
        assert core.collision_checker.collide(create_collision_object(marker))
        assert all(
            actor.prediction.final_time_step == 20
            for actor in core.config.scenario.dynamic_obstacles
        )
        return None

    monkeypatch.setattr(core, "plan", inspect)
    with pytest.raises(NoPathFound):
        adapter.plan(scenario, problem)
    adapter.reset()
    assert not adapter._planners and not adapter._endpoints and not adapter.diagnostics


@pytest.mark.parametrize("failure", ["no_path", "invalid_state"])
def test_core_failures_are_reported_without_fallback(example, monkeypatch, failure):
    original = ReactivePlanner.plan

    def broken(core):
        if failure == "no_path":
            return None
        result = original(core)
        result[0].state_list[1].orientation = np.nan
        return result

    monkeypatch.setattr(ReactivePlanner, "plan", broken)
    adapter = ReactivePlannerAdapter()
    with pytest.raises(NoPathFound if failure == "no_path" else InvalidPlan):
        adapter.plan(*example)
    assert not adapter._endpoints  # A failed call never supplies a replacement trajectory.
