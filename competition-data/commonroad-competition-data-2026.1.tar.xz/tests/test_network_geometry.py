"""Generated traffic geometry respects complete bodies and immutable controls."""

from pathlib import Path
from types import SimpleNamespace
import xml.etree.ElementTree as ET

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.geometry.shape import Rectangle
from commonroad.scenario.lanelet import Lanelet, LaneletNetwork
from commonroad.scenario.obstacle import ObstacleType
from commonroad_sumo.sumolib.sumo_project import SumoFileType
from shapely.geometry import box
from shapely.ops import unary_union

from simulation.conversion import StableMapConverter, _connection_gaps
from simulation.network_geometry import (
    _footprint_area, _lane_chain, _path_model, _read_network,
    prepare_traffic_geometry,
)


class Project:
    def __init__(self, network, routes):
        self.paths = {SumoFileType.NET: network, SumoFileType.VEHICLE_ROUTES: routes}

    def get_file_path(self, kind):
        return self.paths[kind]


def signature(root):
    """Allow geometry attributes only; every route/control assignment survives."""
    return [
        (element.tag, tuple(sorted(
            (key, value) for key, value in element.attrib.items()
            if not (element.tag == 'lane' and key in {'shape', 'length', 'width'})
            and not (element.tag == 'connection' and key == 'shape')
        )))
        for element in root.iter()
    ]


def test_generated_turn_fits_full_car_without_changing_source_or_controls(tmp_path):
    path = Path(__file__).resolve().parents[1] / 'planner/assets/scenarios/public/DEU_EssenCRC26P-52_69240_I-1.xml'
    original = path.read_bytes()
    scenario, _ = CommonRoadFileReader(str(path)).open()
    source_positions = {a.obstacle_id: a.initial_state.position.copy() for a in scenario.dynamic_obstacles}
    project = StableMapConverter(scenario).create_sumo_files(tmp_path)
    network = project.get_file_path(SumoFileType.NET)
    routes = tmp_path / 'traffic.rou.xml'
    routes.write_text('<routes><vehicle id="30431"><route edges="424 454"/></vehicle></routes>')
    controls = signature(ET.parse(network).getroot())
    rows = prepare_traffic_geometry(scenario, Project(network, routes))
    assert any(r['kind'] == 'turn' and 0 < r['maximum_vertex_displacement_m'] < .1 for r in rows)
    assert not any(r['kind'] == 'unfitted-turn' for r in rows)
    assert signature(ET.parse(network).getroot()) == controls
    assert not _connection_gaps(network)
    assert path.read_bytes() == original
    assert routes.read_text() == '<routes><vehicle id="30431"><route edges="424 454"/></vehicle></routes>'
    for actor in scenario.dynamic_obstacles:
        np.testing.assert_array_equal(actor.initial_state.position, source_positions[actor.obstacle_id])
    _, lanes, links, outgoing = _read_network(network)
    turn = next(c for c in links if c.get('from') == '424' and c.get('to') == '454')
    road = unary_union([l.polygon.shapely_object for l in scenario.lanelet_network.lanelets])
    assert _footprint_area(lanes, _lane_chain(turn, outgoing), road, 5., 2., spacing=.01)[0] <= 1e-7


def bicycle_fixture(tmp_path):
    network = tmp_path / 'network.net.xml'
    network.write_text('<net><edge id="1"><lane id="1_0" index="0" length="30" width="3" shape="5,0 35,0"/></edge></net>')
    routes = tmp_path / 'traffic.rou.xml'
    routes.write_text('<routes><vehicle id="7" departPos="4" arrivalPos="28"><route edges="1"/></vehicle></routes>')
    left = np.array([[0., 1.49], [40., 1.49]])
    center = np.array([[0., 0.], [40., 0.]])
    right = np.array([[0., -1.49], [40., -1.49]])
    network_source = LaneletNetwork.create_from_lanelet_list([Lanelet(left, center, right, 1)])
    actor = SimpleNamespace(obstacle_id=7, obstacle_type=ObstacleType.BICYCLE, obstacle_shape=Rectangle(2., .68))
    return SimpleNamespace(lanelet_network=network_source, dynamic_obstacles=[actor]), Project(network, routes)


def test_width_rounding_cannot_send_right_aligned_bicycle_outside_source(tmp_path):
    scenario, project = bicycle_fixture(tmp_path)
    network = project.get_file_path(SumoFileType.NET)
    _, before, _, _ = _read_network(network)
    assert _footprint_area(before, ['1_0'], box(0, -1.49, 40, 1.49), 2., .68, lateral=-1.16)[0] > .001
    changes = prepare_traffic_geometry(scenario, project)
    assert changes and all(row['kind'] == 'width' for row in changes)
    _, lanes, _, _ = _read_network(network)
    width = float(lanes['1_0'].get('width'))
    assert 2.96 < width <= 2.98
    assert _footprint_area(lanes, ['1_0'], box(0, -1.49, 40, 1.49), 2., .68, lateral=-(width - .68) / 2)[0] <= 1e-7
    assert scenario.dynamic_obstacles[0].obstacle_shape.width == .68
    np.testing.assert_array_equal(scenario.lanelet_network.lanelets[0].left_vertices, [[0., 1.49], [40., 1.49]])


def test_failed_network_preparation_preserves_original_file(tmp_path, monkeypatch):
    from simulation import network_geometry
    scenario, project = bicycle_fixture(tmp_path)
    network = project.get_file_path(SumoFileType.NET)
    original = network.read_bytes()
    monkeypatch.setattr(network_geometry, '_connection_gaps', lambda path: [('broken', 1.)])
    with pytest.raises(ValueError, match='connection endpoints'):
        prepare_traffic_geometry(scenario, project)
    assert network.read_bytes() == original
    assert sorted(tmp_path.glob('*.net.xml')) == [network]


def test_lane_position_interpolation_uses_declared_length():
    lane = ET.fromstring('<lane shape="0,0 10,0 10,10" length="10"/>')
    points, distances = _path_model({'a': lane}, ['a'])
    np.testing.assert_array_equal(points, [[0, 0], [10, 0], [10, 10]])
    np.testing.assert_array_equal(distances, [0, 5, 10])


def test_local_curved_lane_cap_preserves_unaffected_next_road(tmp_path):
    network = tmp_path / 'network.net.xml'
    network.write_text('''<net>
      <edge id="1"><lane id="1_0" index="0" length="30.01" width="3" shape="5,0 15,0.3 25,0.3 35,0"/></edge>
      <edge id="2"><lane id="2_0" index="0" length="30" width="3.5" shape="35,0 65,0"/></edge>
      <connection from="1" to="2" fromLane="0" toLane="0"/>
    </net>''')
    routes = tmp_path / 'traffic.rou.xml'
    routes.write_text('<routes><vehicle id="7" departPos="4" arrivalPos="28"><route edges="1 2"/></vehicle></routes>')
    x = np.array([0., 5., 10., 15., 25., 30., 35.])
    y = np.array([0., 0., .15, .3, .3, .15, 0.])
    half_width = np.array([2., 2., 2., 1.49, 1.49, 2., 2.])
    first = Lanelet(np.column_stack([x, y + half_width]), np.column_stack([x, y]), np.column_stack([x, y - half_width]), 1, successor=[2])
    second = Lanelet(np.array([[35., 2.], [70., 2.]]), np.array([[35., 0.], [70., 0.]]), np.array([[35., -2.], [70., -2.]]), 2, predecessor=[1])
    actor = SimpleNamespace(obstacle_id=7, obstacle_type=ObstacleType.BICYCLE, obstacle_shape=Rectangle(2., .68))
    source = SimpleNamespace(lanelet_network=LaneletNetwork.create_from_lanelet_list([first, second]), dynamic_obstacles=[actor])
    rows = prepare_traffic_geometry(source, Project(network, routes))
    assert any(row['kind'] == 'width' and row['lane'] == '1_0' for row in rows)
    _, lanes, _, _ = _read_network(network)
    assert float(lanes['1_0'].get('width')) < 3.
    assert float(lanes['2_0'].get('width')) == 3.5


def test_true_skewed_exit_cap_does_not_block_interior_width_fit(tmp_path):
    scenario, project = bicycle_fixture(tmp_path)
    lane = Lanelet(
        np.array([[0., 1.49], [35.8, 1.49]]),
        np.array([[0., 0.], [35., 0.]]),
        np.array([[0., -1.49], [34.2, -1.49]]),
        1,
    )
    scenario.lanelet_network = LaneletNetwork.create_from_lanelet_list([lane])
    project.paths[SumoFileType.VEHICLE_ROUTES].write_text(
        '<routes><vehicle id="7" departPos="4" arrivalPos="30"><route edges="1"/></vehicle></routes>'
    )
    _, before, _, _ = _read_network(project.paths[SumoFileType.NET])
    # Even a centered body crosses this skewed longitudinal cap at the end;
    # that must not prevent fixing an independent interior lateral spill.
    assert _footprint_area(before, ['1_0'], lane.polygon.shapely_object, 2., .68)[0] > 1e-5
    rows = prepare_traffic_geometry(scenario, project)
    assert rows and all(row['kind'] == 'width' for row in rows)
    _, after, _, _ = _read_network(project.paths[SumoFileType.NET])
    assert float(after['1_0'].get('width')) <= 2.98
