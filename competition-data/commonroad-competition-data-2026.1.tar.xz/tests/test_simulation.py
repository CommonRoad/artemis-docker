"""Real libsumo integration checks; straight-line planner is only a test fixture."""

import shutil
import sys
from copy import deepcopy
from pathlib import Path

import libsumo
import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.file_writer import CommonRoadFileWriter, OverwriteExistingFile
from commonroad.common.solution import (
    CommonRoadSolutionReader,
    CostFunction,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.planning.planning_problem import PlanningProblem
from commonroad.scenario.state import KSState
from commonroad.scenario.trajectory import Trajectory

from simulation.planner_adapter import PlannerAdapter, PlannerOutputError
from simulation.simulations import (
    simulate_with_planner,
    simulate_with_solution,
    simulate_without_ego,
)
from simulation.utility import save_solution
from simulation.video import create_video


DEMOS = Path(__file__).parent / "fixtures" / "legacy" / "demo"


@pytest.fixture(params=sorted(p.name for p in DEMOS.glob("*_I-1.xml")))
def demo(request, tmp_path):
    return Path(shutil.copy2(DEMOS / request.param, tmp_path / request.param))


class StraightPlanner:
    def plan(self, scenario, problem):
        state = problem.initial_state
        next_state = KSState(
            position=state.position
            + state.velocity
            * scenario.dt
            * np.array([np.cos(state.orientation), np.sin(state.orientation)]),
            velocity=state.velocity,
            orientation=state.orientation,
            steering_angle=0.0,
            time_step=state.time_step + 1,
        )
        return Trajectory(next_state.time_step, [next_state])


def test_simulate_export_replay(demo, tmp_path):
    imported = set(sys.modules)
    traffic, _ = simulate_without_ego(demo, num_of_steps=4)
    assert len(traffic.dynamic_obstacles) > 0
    for obstacle in traffic.dynamic_obstacles:
        if obstacle.prediction:
            assert obstacle.prediction.initial_time_step == obstacle.initial_state.time_step + 1
    assert not libsumo.isLoaded()
    calls = []
    observations = []

    class ObservingPlanner(StraightPlanner):
        def plan(self, scenario, problem):
            calls.append(problem.initial_state.time_step)
            observations.append(len(scenario.dynamic_obstacles))
            for obstacle in scenario.dynamic_obstacles:
                assert obstacle.initial_state.time_step <= problem.initial_state.time_step
                if obstacle.prediction:
                    assert (
                        obstacle.prediction.initial_time_step
                        == obstacle.initial_state.time_step + 1
                    )
                    assert obstacle.prediction.final_time_step <= problem.initial_state.time_step
            return super().plan(scenario, problem)

    scenario, problems, egos = simulate_with_planner(
        demo, num_of_steps=4, planner=ObservingPlanner()
    )
    assert calls == [0, 1, 2, 3]
    assert all(observations)
    assert scenario.dynamic_obstacles
    for obstacle in scenario.dynamic_obstacles:
        if obstacle.prediction:
            assert obstacle.prediction.initial_time_step == obstacle.initial_state.time_step + 1
    assert not libsumo.isLoaded()
    assert not any(name.startswith("commonroad_rp") for name in set(sys.modules) - imported)
    for problem_id, ego in egos.items():
        assert problems.planning_problem_dict[problem_id].initial_state.time_step == 0
        assert [s.time_step for s in ego.prediction.trajectory.state_list] == [1, 2, 3, 4]
    saved = save_solution(
        scenario,
        problems,
        egos,
        VehicleType.FORD_ESCORT,
        VehicleModel.KS,
        CostFunction.TR1,
        tmp_path,
    )
    read = CommonRoadSolutionReader.open(str(next(tmp_path.glob("solution*.xml"))))
    assert [s.time_step for s in read.planning_problem_solutions[0].trajectory.state_list] == [
        0,
        1,
        2,
        3,
        4,
    ]
    _, replay_problems, replay_egos = simulate_with_solution(demo, solution=read, num_of_steps=4)
    for problem_id in egos:
        np.testing.assert_allclose(
            replay_egos[problem_id].prediction.trajectory.final_state.position,
            egos[problem_id].prediction.trajectory.final_state.position,
        )
    assert replay_problems.planning_problem_dict[next(iter(egos))].initial_state.time_step == 0
    assert saved.scenario_id == read.scenario_id
    assert not libsumo.isLoaded()

    wrong_id = deepcopy(read)
    wrong_id.planning_problem_solutions[0].planning_problem_id += 1
    with pytest.raises(PlannerOutputError, match="planning problem IDs"):
        simulate_with_solution(demo, solution=wrong_id, num_of_steps=4)


def test_failure_is_visible_and_simulator_can_restart(demo):
    class BrokenPlanner:
        def plan(self, scenario, problem):
            raise RuntimeError("intentional student failure")

    with pytest.raises(Exception) as error:
        simulate_with_planner(demo, num_of_steps=2, planner=BrokenPlanner())
    assert isinstance(error.value.__cause__, RuntimeError)
    assert str(error.value.__cause__) == "intentional student failure"
    assert not libsumo.isLoaded()
    simulate_with_planner(demo, num_of_steps=2, planner=StraightPlanner())
    assert not libsumo.isLoaded()


@pytest.mark.parametrize("failure", ["none", "solution", "stale", "gap", "nan", "position"])
def test_bad_planner_output(demo, failure):
    scenario, problems = CommonRoadFileReader(str(demo)).open()
    problem = next(iter(problems.planning_problem_dict.values()))

    class BadPlanner(StraightPlanner):
        def plan(self, scenario, problem):
            if failure == "none":
                return None
            if failure == "solution":
                return Solution(scenario.scenario_id, [])
            trajectory = super().plan(scenario, problem)
            state = trajectory.state_list[0]
            if failure == "stale":
                state.time_step = problem.initial_state.time_step
            elif failure == "gap":
                state.time_step += 1
            elif failure == "nan":
                state.velocity = np.nan
            else:
                state.position = np.array([1.0, 2.0, 3.0])
            return trajectory

    with pytest.raises(PlannerOutputError):
        PlannerAdapter(BadPlanner()).plan(scenario, problem)


def test_removed_callback_interface_is_rejected():
    with pytest.raises(TypeError, match="Provide a planner with plan"):
        PlannerAdapter(lambda scenario, problem: None)


def test_legacy_sumo_manager_is_rejected(demo):
    with pytest.raises(ValueError, match="SUMO Manager"):
        simulate_without_ego(demo, use_sumo_manager=True)


def test_short_video(demo, tmp_path):
    scenario, problems, egos = simulate_with_planner(
        demo, num_of_steps=2, planner=StraightPlanner()
    )
    filename = create_video(scenario, tmp_path, problems, egos, follow_ego=True)
    assert (tmp_path / filename).stat().st_size > 1000


def test_multiple_planning_problem_ids(demo):
    path = demo
    scenario, problems = CommonRoadFileReader(str(path)).open()
    original = next(iter(problems.planning_problem_dict.values()))
    initial = deepcopy(original.initial_state)
    initial.position = initial.position + np.array([2.0, 0.0])
    problems.add_planning_problem(PlanningProblem(99999, initial, deepcopy(original.goal)))
    CommonRoadFileWriter(
        scenario, problems, author="test", affiliation="test", source="test"
    ).write_to_file(str(path), overwrite_existing_file=OverwriteExistingFile.ALWAYS)
    _, returned, egos = simulate_with_planner(demo, num_of_steps=2, planner=StraightPlanner())
    assert set(egos) == {original.planning_problem_id, 99999}
    assert len({ego.obstacle_id for ego in egos.values()}) == 2
    for problem_id, ego in egos.items():
        np.testing.assert_allclose(
            ego.initial_state.position,
            returned.planning_problem_dict[problem_id].initial_state.position,
        )
    assert not libsumo.isLoaded()
