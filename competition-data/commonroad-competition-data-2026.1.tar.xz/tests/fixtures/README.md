The historical Essen XML and its three recorded trajectory JSON files share one
offline-normalized coordinate frame. Their positions were translated by
`[-781203.2410500001, -6701235.99935]` m with zero rotation, using the lanelet
boundary bounding-box midpoint as the origin. Times and non-position state values
are unchanged. The XML was written at 17 decimal places and tests read it afresh.

These fixtures exercise upstream dynamics checking, invalid-motion rejection and
scoring using the same frame for the map, planning problems, traffic and ego.
