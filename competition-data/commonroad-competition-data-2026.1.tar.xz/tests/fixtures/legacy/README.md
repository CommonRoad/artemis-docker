# Regression fixtures

These historical XMLs exercise conversion, collision timing, initial-state
compatibility and recorded-traffic execution. They are test data, not competition
examples, and are excluded from the participant wheel.

Participant examples use the public XMLs in `planner/assets/scenarios/public/`.
