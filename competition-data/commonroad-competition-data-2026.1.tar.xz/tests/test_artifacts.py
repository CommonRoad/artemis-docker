"""Saved ego/traffic pairs preserve the executed drive and its run identity."""

import hashlib
import json
import shutil
from copy import deepcopy
from dataclasses import asdict, replace
from pathlib import Path
from types import SimpleNamespace
import sys

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.solution import CommonRoadSolutionReader
from commonroad.geometry.shape import Rectangle
from commonroad.scenario.obstacle import ObstacleType, StaticObstacle
from commonroad.scenario.state import InitialState

from planner.common.scenarios import ASSETS
from planner.common.scoring import CostFunctionEvaluator
from planner.common.validation import validate_solution
from planner.runtime.artifacts import export_result, submission_metadata
from planner.runtime.evaluation import describe_result, evaluate_scenario, leaderboard_payload
from planner.runtime.execution import run_spec, run_submission
from planner.runtime.submission import DEFAULT_SUBMISSION
from planner.spec import smp_spec
from simulation.solution_check import valid_solution
import planner.__main__ as cli


@pytest.fixture(scope="module")
def completed_run(tmp_path_factory):
    source = tmp_path_factory.mktemp("paired-source") / "my_submission"
    shutil.copytree(DEFAULT_SUBMISSION, source)
    scenario = ASSETS / "scenarios/public/DEU_AugsburgCRC26P-23_16300_I-1.xml"
    result = run_submission(scenario, source)
    return result, source


def test_saved_pair_preserves_traffic_validity_and_cost(completed_run, tmp_path):
    result, _ = completed_run
    case = export_result(result, tmp_path)
    scenario, problems = CommonRoadFileReader(str(case / "scenario.xml")).open()
    solution = CommonRoadSolutionReader.open(str(case / "solution.xml"))
    assert scenario.scenario_id == result.scenario.scenario_id == solution.scenario_id
    assert len(scenario.obstacles) == len(result.scenario.obstacles)
    for before in result.scenario.dynamic_obstacles:
        after = scenario.obstacle_by_id(before.obstacle_id)
        assert before.obstacle_shape == after.obstacle_shape
        states = [before.initial_state]
        if before.prediction is not None:
            states += before.prediction.trajectory.state_list
        for state in states:
            saved = after.state_at_time(state.time_step)
            np.testing.assert_allclose(saved.position, state.position, rtol=0, atol=1e-9)
            assert saved.velocity == pytest.approx(state.velocity, abs=1e-10)
            assert saved.orientation == pytest.approx(state.orientation, abs=1e-10)
    for key, before in result.planning_problems.planning_problem_dict.items():
        after = problems.planning_problem_dict[key]
        assert after.initial_state.time_step == before.initial_state.time_step
        np.testing.assert_allclose(after.initial_state.position, before.initial_state.position)
        assert after.goal == before.goal
    valid, details = valid_solution(scenario, problems, solution)
    assert valid == result.valid
    assert all(item[0] for item in details.values()) == result.validation.feasible
    assert validate_solution(scenario, problems, solution) == result.validation
    score = CostFunctionEvaluator.init_from_solution(solution).evaluate_solution(
        scenario, problems, solution
    )
    assert score.total_costs == pytest.approx(result.cost, rel=1e-9)
    metadata = json.loads((case / "metadata.json").read_text())
    assert metadata["format_version"] == 2
    assert metadata["validation"] == asdict(result.validation)
    assert metadata["run_id"] == result.metadata["run_id"]
    assert metadata["settings"]["random_seed"] == 1234
    assert metadata["settings"]["simulation_steps"] == 200
    assert metadata["environment"]["packages"]["commonroad-io"] == "2024.3"
    assert metadata["cost_function"] == "SM1"
    for filename, digest in metadata["files"].items():
        assert hashlib.sha256((case / filename).read_bytes()).hexdigest() == digest


def test_invalid_completed_drive_keeps_feedback_and_export(completed_run, tmp_path, monkeypatch):
    original, source = completed_run
    scenario = deepcopy(original.scenario)
    solution = deepcopy(original.solution)
    initial = solution.planning_problem_solutions[0].trajectory.state_list[0]
    scenario.add_objects(
        StaticObstacle(
            scenario.generate_object_id(),
            ObstacleType.CAR,
            Rectangle(4.5, 1.8),
            InitialState(
                position=initial.position.copy(),
                orientation=initial.orientation,
                time_step=initial.time_step,
            ),
        )
    )
    # Reuse a completed drive to exercise the runner's invalid-result path.
    monkeypatch.setattr(
        "planner.runtime.execution.run_motion_planner_interactive",
        lambda *args, **kwargs: (scenario, solution),
    )

    def unexpected_scoring(*args, **kwargs):
        raise AssertionError("Invalid drives must not be scored")

    monkeypatch.setattr(CostFunctionEvaluator, "init_from_solution", unexpected_scoring)
    path = ASSETS / f"scenarios/public/{scenario.scenario_id}.xml"
    result = run_spec(path, smp_spec())
    assert not result.valid and result.cost is None
    assert result.validation.feasible is None
    assert "collision" in result.validation.message
    assert describe_result(result)["feasible"] is None
    monkeypatch.setattr("planner.runtime.evaluation.run_submission", lambda *args: result)
    feedback = evaluate_scenario(path, source)
    assert not feedback.passed and feedback.status == "invalid_solution"
    assert feedback.message == result.validation.message

    case = export_result(result, tmp_path)
    metadata = json.loads((case / "metadata.json").read_text())
    assert metadata["validation"] == asdict(result.validation)
    assert metadata["cost"] is None
    saved, problems = CommonRoadFileReader(str(case / "scenario.xml")).open()
    saved_solution = CommonRoadSolutionReader.open(str(case / "solution.xml"))
    assert validate_solution(saved, problems, saved_solution) == result.validation


@pytest.mark.parametrize("filename", ["later_edit.py", "weights.bin"])
def test_export_keeps_source_identity_from_execution(completed_run, tmp_path, filename):
    result, source = completed_run
    before = result.metadata["source"].copy()
    helper = source / filename
    helper.write_text("CHANGED_AFTER_RUN = True\n")
    try:
        assert submission_metadata(source) != before
        case = export_result(result, tmp_path)
        metadata = json.loads((case / "metadata.json").read_text())
        assert metadata["source"] == before
        export_result(result, tmp_path)
        assert sorted(p.name for p in case.iterdir()) == [
            "metadata.json",
            "scenario.xml",
            "solution.xml",
        ]
    finally:
        helper.unlink()


@pytest.mark.parametrize("failure", ["exception", "nan", "inf"])
def test_scoring_failure_retains_completed_drive(completed_run, tmp_path, monkeypatch, failure):
    original, source = completed_run
    monkeypatch.setattr(
        "planner.runtime.execution.run_motion_planner_interactive",
        lambda *args, **kwargs: (original.scenario, original.solution),
    )

    def score(*args):
        if failure == "exception":
            raise RuntimeError("cannot project completed route")
        return SimpleNamespace(total_costs=float(failure))

    monkeypatch.setattr(
        CostFunctionEvaluator,
        "init_from_solution",
        lambda solution: SimpleNamespace(evaluate_solution=score),
    )
    path = ASSETS / f"scenarios/public/{original.scenario.scenario_id}.xml"
    result = run_spec(path, smp_spec())
    assert result.valid and result.cost is None
    assert result.scoring_error
    assert ("cannot project" if failure == "exception" else "non-finite") in result.scoring_error
    assert describe_result(result)["scoring_error"] == result.scoring_error

    monkeypatch.setattr("planner.runtime.evaluation.run_submission", lambda *args: result)
    feedback = evaluate_scenario(path, source)
    assert not feedback.passed and feedback.status == "scoring_error"
    assert feedback.message == result.scoring_error and feedback.score is None
    assert leaderboard_payload("student", [feedback])["results"][0]["score"] == 0.0
    case = export_result(result, tmp_path)
    metadata = json.loads((case / "metadata.json").read_text())
    assert metadata["validation"]["valid"]
    assert metadata["cost"] is None and metadata["scoring_error"] == result.scoring_error
    saved, problems = CommonRoadFileReader(str(case / "scenario.xml")).open()
    assert validate_solution(
        saved, problems, CommonRoadSolutionReader.open(str(case / "solution.xml"))
    ).valid


@pytest.mark.parametrize("phase", ["scenario", "solution", "metadata", "interrupt"])
def test_failed_export_keeps_previous_pair(completed_run, tmp_path, monkeypatch, phase):
    result, _ = completed_run
    case = export_result(result, tmp_path)
    (case / "notes.txt").write_text("participant notes\n")
    before = {path.name: path.read_bytes() for path in case.iterdir()}

    def fail_write(*args, **kwargs):
        if phase == "interrupt":
            Path(kwargs["output_path"], "solution.xml").write_text("partial XML")
            raise KeyboardInterrupt()
        raise OSError("export interrupted")

    if phase == "scenario":
        monkeypatch.setattr("planner.runtime.artifacts.CommonRoadFileWriter.write_to_file", fail_write)
    elif phase in {"solution", "interrupt"}:
        monkeypatch.setattr("planner.runtime.artifacts.CommonRoadSolutionWriter.write_to_file", fail_write)
    else:
        result = replace(result, metadata={**result.metadata, "unserializable": object()})

    expected = KeyboardInterrupt if phase == "interrupt" else TypeError if phase == "metadata" else OSError
    with pytest.raises(expected):
        export_result(result, tmp_path)
    assert {path.name: path.read_bytes() for path in case.iterdir()} == before
    assert list(tmp_path.iterdir()) == [case]


def test_cli_reruns_replace_completed_results_and_retain_failed_attempts(
    completed_run, tmp_path, monkeypatch, capsys
):
    original, _ = completed_run
    scenario_path = ASSETS / f"scenarios/public/{original.scenario.scenario_id}.xml"
    monkeypatch.setattr(
        sys, "argv", ["planner", "--scenarios", str(scenario_path), "--solutions", str(tmp_path)]
    )
    monkeypatch.setattr(cli, "run_submission", lambda *args: original)
    assert cli.main() == 0
    case = tmp_path / str(original.scenario.scenario_id)
    (case / "notes.txt").write_text("participant notes\n")

    invalid = replace(
        original,
        validation=replace(original.validation, valid=False, message="Goal not reached."),
        cost=None,
    )
    monkeypatch.setattr(cli, "run_submission", lambda *args: invalid)
    assert cli.main() == 1
    before_failure = {path.name: path.read_bytes() for path in case.iterdir()}
    assert not json.loads((case / "metadata.json").read_text())["validation"]["valid"]

    def fail_run(*args):
        raise RuntimeError("planner failed on rerun")

    monkeypatch.setattr(cli, "run_submission", fail_run)
    assert cli.main() == 1
    assert "Previous result retained" in capsys.readouterr().out
    assert {path.name: path.read_bytes() for path in case.iterdir()} == before_failure

    unscored = replace(original, cost=None, scoring_error="RuntimeError: cannot project route")
    monkeypatch.setattr(cli, "run_submission", lambda *args: unscored)
    assert cli.main() == 1
    assert "scoring_error" in capsys.readouterr().out
    assert json.loads((case / "metadata.json").read_text())["scoring_error"] == unscored.scoring_error

    monkeypatch.setattr(cli, "run_submission", lambda *args: original)
    assert cli.main() == 0
    assert json.loads((case / "metadata.json").read_text())["validation"]["valid"]
    assert (case / "notes.txt").read_text() == "participant notes\n"
