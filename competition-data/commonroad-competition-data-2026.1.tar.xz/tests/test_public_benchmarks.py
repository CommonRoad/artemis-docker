"""The published starters use the same runner and validity rules as submissions."""

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader

from planner.common.scenarios import ASSETS, public_scenarios
from planner.runtime.execution import run_spec
from planner.spec import reactive_spec, smp_spec


STARTERS = [
    ASSETS / "scenarios/public/DEU_AugsburgCRC26P-23_16300_I-1.xml",
    ASSETS / "scenarios/public/DEU_FlensburgCRC26E-71_11400_I-1.xml",
    ASSETS / "scenarios/public/DEU_ErlangenCRC26P-12_17300_I-1.xml",
]


def test_public_selection_contract():
    paths = public_scenarios()
    assert len(paths) == len(set(paths)) == 100
    assert sum("CRC26P" in path.stem for path in paths) == 50
    assert sum("CRC26E" in path.stem for path in paths) == 50
    assert set(paths) == set((ASSETS / "scenarios" / "public").glob("*.xml"))
    assert set(STARTERS) <= set(paths)
    for path in paths:
        scenario, problems = CommonRoadFileReader(str(path)).open()
        assert str(scenario.scenario_id) == path.stem
        assert "_I-" in path.stem
        for problem in problems.planning_problem_dict.values():
            for goal in problem.goal.state_list:
                assert hasattr(goal, "position")
                assert goal.time_step.start == 1
                assert goal.time_step.end <= 200


@pytest.mark.parametrize("path", STARTERS, ids=lambda path: path.stem)
@pytest.mark.parametrize("factory", [smp_spec, reactive_spec], ids=["search", "reactive"])
def test_shared_starters(path, factory, capfd):
    result = run_spec(path, factory())
    captured = capfd.readouterr()
    assert "Warning:" not in captured.err
    assert result.valid and result.validation.feasible
    assert np.isfinite(result.cost)
