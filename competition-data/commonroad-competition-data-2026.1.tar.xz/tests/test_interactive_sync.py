"""Real SUMO snapshots and collision events must describe the exported instant."""

from copy import deepcopy

import libsumo
import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.file_writer import CommonRoadFileWriter, OverwriteExistingFile
from commonroad.common.solution import (
    CommonRoadSolutionReader,
    CostFunction,
    VehicleModel,
    VehicleType,
)
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.planning.planning_problem import PlanningProblem, PlanningProblemSet
from commonroad.prediction.prediction import TrajectoryPrediction
from commonroad.scenario.lanelet import Lanelet
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType
from commonroad.scenario.scenario import Scenario, ScenarioID
from commonroad.scenario.state import CustomState, InitialState, KSState
from commonroad.scenario.trajectory import Trajectory

from simulation.interactive import InteractiveSimulation
from simulation.simulations import SimulationSettings, run_simulation
from simulation.utility import save_solution


def _initial(position, *, speed=5.0, heading=0.0, step=0) -> InitialState:
    return InitialState(
        position=np.asarray(position, dtype=float),
        velocity=float(speed),
        orientation=float(heading),
        acceleration=0.0,
        yaw_rate=0.0,
        slip_angle=0.0,
        time_step=step,
    )


def _straight_case(
    *, traffic=None, ego=None, goal_step=100
) -> tuple[Scenario, PlanningProblemSet]:
    scenario = Scenario(0.1, ScenarioID(country_id="ZAM", map_name="Sync", map_id=1))
    longitudinal = np.array([-20.0, 0.0, 50.0, 100.0, 200.0])
    center = np.column_stack((longitudinal, np.zeros_like(longitudinal)))
    scenario.add_objects(Lanelet(center + [0.0, 3.0], center, center - [0.0, 3.0], 1))
    traffic = traffic or _initial([50.0, 0.0], speed=4.0)
    shape = Rectangle(4.5, 1.8)
    direction = np.array([np.cos(traffic.orientation), np.sin(traffic.orientation)])
    future = []
    for offset in range(1, 31):
        state = deepcopy(traffic)
        state.time_step += offset
        state.position += offset * scenario.dt * traffic.velocity * direction
        future.append(state)
    scenario.add_objects(
        DynamicObstacle(
            100,
            ObstacleType.CAR,
            shape,
            traffic,
            TrajectoryPrediction(Trajectory(future[0].time_step, future), shape),
        )
    )
    problem = PlanningProblem(
        10,
        ego or _initial([10.0, 0.0]),
        GoalRegion([CustomState(time_step=Interval(goal_step, goal_step + 20))]),
    )
    return scenario, PlanningProblemSet([problem])


class _StraightPlanner:
    def __init__(self, horizon=10, acceleration=0.0):
        self.horizon = horizon
        self.acceleration = acceleration
        self.calls = []
        self.observations = []
        self.plans = []

    def plan(self, scenario, problem):
        current = problem.initial_state
        self.calls.append(current.time_step)
        self.observations.append(deepcopy(scenario))
        direction = np.array([np.cos(current.orientation), np.sin(current.orientation)])
        states = []
        for offset in range(1, self.horizon + 1):
            elapsed = offset * scenario.dt
            states.append(
                KSState(
                    position=current.position
                    + (current.velocity * elapsed + 0.5 * self.acceleration * elapsed**2)
                    * direction,
                    orientation=current.orientation,
                    velocity=current.velocity + self.acceleration * elapsed,
                    steering_angle=0.0,
                    time_step=current.time_step + offset,
                )
            )
        trajectory = Trajectory(states[0].time_step, states)
        self.plans.append(deepcopy(trajectory))
        return trajectory


@pytest.fixture
def observed_run(monkeypatch):
    instances = []

    class ObservedSimulation(InteractiveSimulation):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.snapshots = {}
            instances.append(self)

        def _post_simulation_step_hook(self, step):
            super()._post_simulation_step_hook(step)
            actors = {}
            for actor_id in libsumo.vehicle.getIDList():
                heading = np.deg2rad(90.0 - libsumo.vehicle.getAngle(actor_id))
                length = libsumo.vehicle.getLength(actor_id)
                center = np.asarray(libsumo.vehicle.getPosition(actor_id)) - 0.5 * length * np.array(
                    [np.cos(heading), np.sin(heading)]
                )
                actors[int(actor_id)] = (
                    center,
                    heading,
                    libsumo.vehicle.getSpeed(actor_id),
                    libsumo.vehicle.getMinGap(actor_id),
                )
            self.snapshots[step] = (libsumo.simulation.getTime(), actors)

    monkeypatch.setattr(
        "simulation.simulations.InteractiveSumoSimulationWithMotionPlanner", ObservedSimulation
    )

    def run(scenario, problems, planner=None, *, steps=5, interval=1):
        result = run_simulation(
            scenario,
            problems,
            planner or _StraightPlanner(),
            settings=SimulationSettings(simulation_steps=steps, replanning_interval=interval),
        )
        assert not libsumo.isLoaded()
        return result, instances[-1]

    return run


def _assert_raw_matches_export(result, runner) -> None:
    actors = [*result.scenario.dynamic_obstacles, *result.ego_vehicles.values()]
    for step, (sumo_time, raw) in runner.snapshots.items():
        assert sumo_time == pytest.approx((step + 1) * result.scenario.dt)
        assert set(raw) == {a.obstacle_id for a in actors if a.state_at_time(step) is not None}
        for actor in actors:
            state = actor.state_at_time(step)
            if state is None:
                continue
            position, heading, velocity, _ = raw[actor.obstacle_id]
            np.testing.assert_allclose(position, state.position, atol=1e-8, rtol=0)
            angle_error = np.arctan2(
                np.sin(heading - state.orientation), np.cos(heading - state.orientation)
            )
            assert angle_error == pytest.approx(0.0, abs=1e-8)
            assert velocity == pytest.approx(state.velocity, abs=1e-8)


@pytest.mark.parametrize("heading", [0.0, 0.2])
def test_initial_and_moving_snapshots_match_export(observed_run, heading):
    scenario, problems = _straight_case(ego=_initial([10.0, 0.0], heading=heading))
    planner = _StraightPlanner(acceleration=0.8)
    result, runner = observed_run(scenario, problems, planner, interval=3)
    _assert_raw_matches_export(result, runner)
    assert planner.calls == [0, 3]
    assert sorted(runner.snapshots) == list(range(6))
    ego = result.ego_vehicles[10]
    assert ego.state_at_time(5).velocity > ego.initial_state.velocity
    assert result.scenario.obstacle_by_id(100).state_at_time(1).position[0] > 50.0


def test_following_traffic_responds_to_synchronized_ego(observed_run):
    scenario, problems = _straight_case(
        traffic=_initial([10.0, 0.0], speed=5.0),
        ego=_initial([20.0, 0.0], speed=3.0),
    )
    result, runner = observed_run(scenario, problems)
    _assert_raw_matches_export(result, runner)
    follower = result.scenario.obstacle_by_id(100)
    assert follower.state_at_time(1).velocity < follower.initial_state.velocity
    assert follower.state_at_time(5).velocity < follower.state_at_time(1).velocity
    assert runner.collision_events == []


@pytest.mark.parametrize("ego_start", [0, 3], ids=["late-traffic", "late-traffic-and-ego"])
def test_late_traffic_and_ego_arrive_at_their_initial_step(observed_run, ego_start):
    scenario, problems = _straight_case(
        traffic=_initial([50.0, 0.0], speed=4.0, step=2),
        ego=_initial([10.0, 0.0], heading=0.2, step=ego_start),
    )
    planner = _StraightPlanner()
    result, runner = observed_run(scenario, problems, planner)
    _assert_raw_matches_export(result, runner)
    ego_id = result.ego_vehicles[10].obstacle_id
    for step, (_, raw) in runner.snapshots.items():
        assert (100 in raw) is (step >= 2)
        assert (ego_id in raw) is (step >= ego_start)
    assert planner.calls == list(range(ego_start, 5))
    for step, observation in zip(planner.calls, planner.observations):
        actor = observation.obstacle_by_id(100)
        if step < 2:
            assert actor is None
        else:
            assert actor.state_at_time(step) is not None


def test_goal_inside_queued_plan_exports_only_executed_states(observed_run, tmp_path):
    scenario, problems = _straight_case(goal_step=2)
    planner = _StraightPlanner(horizon=10)
    result, runner = observed_run(scenario, problems, planner, steps=8, interval=5)
    _assert_raw_matches_export(result, runner)
    assert planner.calls == [0]
    assert planner.plans[0].final_state.time_step == 10
    assert sorted(runner.snapshots) == [0, 1, 2]
    assert result.ego_vehicles[10].prediction.final_time_step == 2
    assert result.scenario.obstacle_by_id(100).prediction.final_time_step == 2
    save_solution(
        result.scenario,
        problems,
        result.ego_vehicles,
        VehicleType.FORD_ESCORT,
        VehicleModel.KS,
        CostFunction.SM1,
        tmp_path,
    )
    solution = CommonRoadSolutionReader.open(str(next(tmp_path.glob("solution*.xml"))))
    assert [s.time_step for s in solution.planning_problem_solutions[0].trajectory.state_list] == [
        0,
        1,
        2,
    ]
    traffic_path = tmp_path / "traffic.xml"
    CommonRoadFileWriter(
        result.scenario,
        problems,
        author="test",
        affiliation="test",
        source="synthetic synchronization regression",
        tags=set(),
    ).write_to_file(
        str(traffic_path), overwrite_existing_file=OverwriteExistingFile.ALWAYS
    )
    exported, _ = CommonRoadFileReader(str(traffic_path)).open()
    assert exported.obstacle_by_id(100).prediction.final_time_step == 2


def test_sub_min_gap_separation_is_not_body_contact(observed_run, capfd):
    scenario, problems = _straight_case(traffic=_initial([16.0, 0.0], speed=5.0))
    result, runner = observed_run(scenario, problems)
    _assert_raw_matches_export(result, runner)
    ego = result.ego_vehicles[10]
    actor = result.scenario.obstacle_by_id(100)
    gap = actor.initial_state.position[0] - ego.initial_state.position[0] - 0.5 * (
        actor.obstacle_shape.length + ego.obstacle_shape.length
    )
    assert 0.0 < gap < runner.snapshots[0][1][ego.obstacle_id][3]
    assert runner.snapshots[0][1][ego.obstacle_id][3] == pytest.approx(2.5)
    assert runner.collision_events == []
    assert "collision with vehicle" not in capfd.readouterr().err


def test_native_body_contact_remains_a_physical_collision(observed_run, capfd):
    scenario, problems = _straight_case(traffic=_initial([13.0, 0.0], speed=5.0))
    result, runner = observed_run(scenario, problems, steps=2)
    _assert_raw_matches_export(result, runner)
    pair = (100, result.ego_vehicles[10].obstacle_id)
    reported = [event for event in runner.collision_events if event["sumo_pairs"]]
    assert reported
    for event in reported:
        assert event["sumo_pairs"] == event["physical_pairs"] == [pair]
        assert event["geometry_disagreements"] == []
    assert "collision with vehicle" in capfd.readouterr().err


@pytest.mark.parametrize("contact", [False, True], ids=["lane-phantom", "unreported-contact"])
def test_native_and_rigid_body_collision_classification(observed_run, contact):
    # Perpendicular remote cars expose SUMO's lane-derived rear geometry on a tiny map.
    traffic = _initial([12.0 if contact else 8.0, 0.0], speed=0.0)
    ego = _initial([12.0, 2.0 if contact else -2.0], speed=0.0, heading=np.pi / 2)
    scenario, problems = _straight_case(traffic=traffic, ego=ego)
    result, runner = observed_run(scenario, problems, steps=2)
    _assert_raw_matches_export(result, runner)
    ego = result.ego_vehicles[10]
    actor = result.scenario.obstacle_by_id(100)
    pair = tuple(sorted((actor.obstacle_id, ego.obstacle_id)))
    assert runner.collision_events
    for event in runner.collision_events:
        step = event["step"]
        bodies_touch = actor.occupancy_at_time(step).shape.shapely_object.intersects(
            ego.occupancy_at_time(step).shape.shapely_object
        )
        assert bodies_touch is contact
        assert event["physical_pairs"] == ([pair] if contact else [])
        assert event["sumo_pairs"] == ([] if contact else [pair])
        assert event["geometry_disagreements"] == ([] if contact else [pair])
    assert any(event["step"] > 0 for event in runner.collision_events)
