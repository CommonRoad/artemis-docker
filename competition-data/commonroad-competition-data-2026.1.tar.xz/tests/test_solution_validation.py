"""Full validation keeps upstream decisions and reports failures without guessing."""

import numpy as np
import pytest
from commonroad.common.solution import (
    CostFunction,
    PlanningProblemSolution,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.planning.planning_problem import PlanningProblem, PlanningProblemSet
from commonroad.scenario.lanelet import Lanelet
from commonroad.scenario.obstacle import ObstacleType, StaticObstacle
from commonroad.scenario.scenario import Scenario
from commonroad.scenario.state import CustomState, InitialState, KSState
from commonroad.scenario.trajectory import Trajectory
from commonroad_dc.feasibility import solution_checker as upstream

from planner.common.validation import validate_solution
from simulation import solution_check


@pytest.fixture
def straight_drive():
    scenario = Scenario(dt=0.1)
    scenario.add_objects(
        Lanelet(
            np.array([[-20.0, 5.0], [50.0, 5.0]]),
            np.array([[-20.0, 0.0], [50.0, 0.0]]),
            np.array([[-20.0, -5.0], [50.0, -5.0]]),
            lanelet_id=1,
        )
    )
    initial = InitialState(
        position=np.array([0.0, 0.0]),
        orientation=0.0,
        velocity=5.0,
        acceleration=0.0,
        yaw_rate=0.0,
        slip_angle=0.0,
        time_step=0,
    )
    goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(2.0, 2.0, np.array([10.0, 0.0])),
                time_step=Interval(1, 40),
            )
        ]
    )
    problems = PlanningProblemSet([PlanningProblem(100, initial, goal)])
    states = [
        KSState(
            position=np.array([0.5 * step, 0.0]),
            velocity=5.0,
            orientation=0.0,
            steering_angle=0.0,
            time_step=step,
        )
        for step in range(21)
    ]
    solution = Solution(
        scenario.scenario_id,
        [
            PlanningProblemSolution(
                100,
                VehicleModel.KS,
                VehicleType.FORD_ESCORT,
                CostFunction.SM1,
                Trajectory(0, states),
            )
        ],
    )
    return scenario, problems, solution


@pytest.mark.parametrize("infeasible", [False, True])
def test_validity_uses_first_boolean_even_with_nonempty_details(straight_drive, infeasible):
    scenario, problems, solution = straight_drive
    if infeasible:
        solution.planning_problem_solutions[0].trajectory.state_list[10].position[0] += 0.5
    valid, details = upstream.valid_solution(scenario, problems, solution)
    assert details  # Its truthiness must never stand in for overall validity.
    result = validate_solution(scenario, problems, solution)
    assert result.valid == valid == (not infeasible)
    assert result.feasible == all(item[0] for item in details.values()) == (not infeasible)
    if infeasible:
        assert "100" in result.message and "feasibility failed" in result.message


@pytest.mark.parametrize("failure", ["collision", "boundary", "goal", "initial", "missing"])
def test_checker_exceptions_preserve_reason_and_unknown_feasibility(straight_drive, failure):
    scenario, problems, solution = straight_drive
    problem = problems.planning_problem_dict[100]
    trajectory = solution.planning_problem_solutions[0].trajectory
    if failure == "collision":
        scenario.add_objects(
            StaticObstacle(
                200,
                ObstacleType.CAR,
                Rectangle(1.0, 1.0),
                InitialState(position=np.array([5.0, 0.0]), orientation=0.0, time_step=0),
            )
        )
    elif failure == "boundary":
        trajectory.state_list[10].position[1] = 5.0
    elif failure == "goal":
        problem.goal.state_list[0].position = Rectangle(2.0, 2.0, np.array([40.0, 0.0]))
    elif failure == "initial":
        trajectory.state_list[0].position[0] = 1.0
    else:
        solution.planning_problem_solutions = []

    with pytest.raises(upstream.SolutionCheckerException) as error:
        upstream.valid_solution(scenario, problems, solution)
    result = validate_solution(scenario, problems, solution)
    assert not result.valid
    assert result.feasible is None
    assert result.message == str(error.value)


def test_invalid_structure_remains_an_error(straight_drive):
    scenario, problems, _ = straight_drive
    with pytest.raises(AttributeError):
        validate_solution(scenario, problems, None)


def test_compatibility_imports_are_the_upstream_implementations():
    for name in solution_check.__all__:
        assert getattr(solution_check, name) is getattr(upstream, name)
