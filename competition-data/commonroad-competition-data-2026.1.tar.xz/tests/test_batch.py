"""Batch reports distinguish driving, scoring and export outcomes, including old results."""

from pathlib import Path
from types import SimpleNamespace
import xml.etree.ElementTree as ET

import pytest

from planner.common.errors import NoPathFound
import planner.runtime.batch as batch


@pytest.mark.parametrize(
    "valid,scoring_error,status",
    [(True, None, "passed"), (False, None, "invalid_solution"),
     (True, "scorer unavailable", "scoring_error")],
)
def test_completed_drives_are_exported_with_distinct_outcomes(
    tmp_path, monkeypatch, valid, scoring_error, status
):
    result = SimpleNamespace(
        scenario=SimpleNamespace(scenario_id="case"),
        valid=valid,
        validation=SimpleNamespace(feasible=True, message="validation details"),
        cost=12.0 if valid and not scoring_error else None,
        scoring_error=scoring_error,
    )
    exported = []
    monkeypatch.setattr(batch, "run_submission", lambda *args: result)

    def export(completed, directory):
        exported.append(completed)
        return directory / "case"

    monkeypatch.setattr(batch, "export_result", export)
    record, = batch.run_batch([tmp_path / "case.xml"], tmp_path, tmp_path / "results")
    assert exported == [result]
    assert record.status == status and record.valid is valid
    assert record.cost == result.cost
    assert record.message == (scoring_error or "validation details")
    assert Path(record.output_directory).name == "case"
    assert not record.previous_result_retained


def test_wrapped_planning_failure_retains_old_result_and_continues(tmp_path, monkeypatch):
    destination = tmp_path / "results" / "failed"
    destination.mkdir(parents=True)
    metadata = destination / "metadata.json"
    metadata.write_text("previous result")
    visited = []

    def fail(path, submission):
        visited.append(path.name)
        try:
            raise NoPathFound("no route")
        except NoPathFound as error:
            raise RuntimeError("simulator wrapper") from error

    monkeypatch.setattr(batch, "run_submission", fail)
    records = list(batch.run_batch(
        [tmp_path / "failed.xml", tmp_path / "next.xml"], tmp_path, tmp_path / "results"
    ))
    assert visited == ["failed.xml", "next.xml"]
    assert [record.status for record in records] == ["no_path", "no_path"]
    assert records[0].message == "NoPathFound: no route"
    assert records[0].previous_result_retained and not records[1].previous_result_retained
    assert all(record.valid is None and record.output_directory is None for record in records)
    assert metadata.read_text() == "previous result"


def test_export_failure_preserves_drive_outcome_and_reports_old_files(tmp_path, monkeypatch):
    destination = tmp_path / "case"
    destination.mkdir()
    (destination / "metadata.json").write_text("previous result")
    result = SimpleNamespace(
        scenario=SimpleNamespace(scenario_id="case"), valid=True, cost=12.0,
        validation=SimpleNamespace(feasible=True, message=""), scoring_error=None,
    )
    monkeypatch.setattr(batch, "run_submission", lambda *args: result)

    def fail_export(*args):
        raise OSError("disk full")

    monkeypatch.setattr(batch, "export_result", fail_export)
    record, = batch.run_batch([tmp_path / "case.xml"], tmp_path, tmp_path)
    assert record.status == "export_error" and "disk full" in record.message
    assert record.valid and record.cost == 12.0
    assert record.output_directory is None and record.previous_result_retained


def test_invalid_worker_count_is_rejected_before_running(tmp_path):
    with pytest.raises(ValueError, match="at least 1"):
        list(batch.run_batch([], tmp_path, tmp_path, workers=0))


def test_worker_exit_is_reported_without_losing_other_results(tmp_path, monkeypatch):
    class Future:
        def __init__(self, path):
            self.path = path

        def result(self):
            if self.path.stem == "failed":
                raise RuntimeError("worker exited")
            return batch.BatchResult(self.path.stem, "passed", True, True, 1.0,
                                     "", 0.5, str(tmp_path / self.path.stem), False)

    class Pool:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def submit(self, func, path, submission, directory):
            return Future(path)

    monkeypatch.setattr(batch, "ProcessPoolExecutor", Pool)
    monkeypatch.setattr(batch, "as_completed", lambda futures: iter(futures))
    destination = tmp_path / "failed"
    destination.mkdir()
    (destination / "metadata.json").write_text("previous result")
    records = list(batch.run_batch(
        [tmp_path / "failed.xml", tmp_path / "passed.xml"], tmp_path, tmp_path, workers=2
    ))
    assert [record.status for record in records] == ["worker_error", "passed"]
    assert "RuntimeError: worker exited" == records[0].message
    assert records[0].output_directory is None and records[0].previous_result_retained
    assert records[0].elapsed_seconds is None
    assert records[1].cost == 1.0


def test_rejected_submission_gets_its_own_worker_record(tmp_path, monkeypatch):
    class Pool:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def submit(self, *args):
            raise RuntimeError("pool already broken")

    monkeypatch.setattr(batch, "ProcessPoolExecutor", Pool)
    records = list(batch.run_batch(
        [tmp_path / "a.xml", tmp_path / "b.xml"], tmp_path, tmp_path, workers=2
    ))
    assert [record.scenario_name for record in records] == ["a", "b"]
    assert all(record.status == "worker_error" and record.elapsed_seconds is None
               for record in records)


def test_xml_parser_numeric_code_is_reported_as_a_named_failure(tmp_path, monkeypatch):
    path = tmp_path / "malformed.xml"
    path.write_text("<broken")
    monkeypatch.setattr(batch, "run_submission", lambda path, submission: ET.parse(path))
    record, = batch.run_batch([path], tmp_path, tmp_path)
    assert record.status == "planner_error"
    assert record.message.startswith("ParseError:") and record.output_directory is None
