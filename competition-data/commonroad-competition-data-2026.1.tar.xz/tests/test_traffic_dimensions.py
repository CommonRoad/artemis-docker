"""Traffic center conversion must use the same physical length in both directions."""

from unittest.mock import patch

import libsumo
import numpy as np
from commonroad.common.file_reader import CommonRoadFileReader
from simulation.interactive import InteractiveSimulation

from legacy_scenarios import introductory_scenarios
from simulation.simulations import SimulationSettings, run_simulation
from test_simulation import StraightPlanner


def test_source_geometry_survives_initial_sumo_calibration():
    source = introductory_scenarios()[0]
    scenario, problems = CommonRoadFileReader(str(source)).open()
    dimensions = {}

    class ObservedSimulation(InteractiveSimulation):
        def _post_simulation_step_hook(self, step):
            if step == 0:
                for actor in scenario.dynamic_obstacles:
                    actor_id = str(actor.obstacle_id)
                    if actor_id in libsumo.vehicle.getIDList():
                        dimensions[actor.obstacle_id] = (
                            libsumo.vehicle.getLength(actor_id),
                            libsumo.vehicle.getWidth(actor_id),
                        )
            super()._post_simulation_step_hook(step)

    target = "simulation.simulations.InteractiveSumoSimulationWithMotionPlanner"
    with patch(target, ObservedSimulation):
        result = run_simulation(
            scenario, problems, StraightPlanner(), settings=SimulationSettings(simulation_steps=1)
        )
    for actor in scenario.dynamic_obstacles:
        np.testing.assert_allclose(
            dimensions[actor.obstacle_id],
            [actor.obstacle_shape.length, actor.obstacle_shape.width],
        )
        observed = result.scenario.obstacle_by_id(actor.obstacle_id)
        np.testing.assert_allclose(
            observed.state_at_time(0).position, actor.initial_state.position, atol=1e-8, rtol=0
        )
    assert not libsumo.isLoaded()
