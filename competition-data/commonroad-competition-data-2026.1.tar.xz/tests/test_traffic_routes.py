"""Real SUMO source/sink geometry must not request nonexistent adjoining roads."""

from dataclasses import asdict

import numpy as np
import pytest
import sumolib
from commonroad.geometry.shape import Rectangle
from commonroad.prediction.prediction import TrajectoryPrediction
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType
from commonroad.scenario.state import InitialState, KSState
from commonroad.scenario.trajectory import Trajectory
from commonroad_sumo.cr2sumo import (
    ResimulationTrafficGeneratorConfig,
    UnsafeResimulationTrafficGenerator,
)

from simulation.traffic import TerminalAwareTrafficGenerator


def _network(tmp_path, continuations=False):
    edges = [("road", "source", "sink", 0, 10)]
    if continuations:
        edges = [("before", "begin", "source", -10, 0), *edges,
                 ("after", "sink", "end", 10, 20)]
    elements = [
        '<net version="1.20"><location netOffset="0,0" convBoundary="-10,-2,20,2" '
        'origBoundary="-10,-2,20,2" projParameter="!"/>'
    ]
    for name, source, target, start, end in edges:
        elements.append(
            f'<edge id="{name}" from="{source}" to="{target}" priority="1">'
            f'<lane id="{name}_0" index="0" speed="13.89" length="10" '
            f'shape="{start},0 {end},0"/></edge>'
        )
    nodes = [("source", 0, "before_0" if continuations else ""), ("sink", 10, "road_0")]
    if continuations:
        nodes += [("begin", -10, ""), ("end", 20, "after_0")]
    for name, x, incoming in nodes:
        elements.append(
            f'<junction id="{name}" x="{x}" y="0" type="priority" incLanes="{incoming}" '
            f'intLanes="" shape="{x-.5},-1 {x+.5},-1 {x+.5},1 {x-.5},1"/>'
        )
    if continuations:
        for source, target in [("before", "road"), ("road", "after")]:
            elements.append(f'<connection from="{source}" to="{target}" fromLane="0" '
                            'toLane="0" dir="s" state="M"/>')
    path = tmp_path / "network.net.xml"
    path.write_text("".join([*elements, "</net>"]))
    return sumolib.net.readNet(str(path))


def _obstacle(start, finish):
    shape = Rectangle(4.0, 2.0)
    initial = InitialState(position=np.array([start, 0.]), orientation=0., velocity=3., time_step=0)
    final = KSState(position=np.array([finish, 0.]), orientation=0., velocity=3.,
                    steering_angle=0., time_step=1)
    return DynamicObstacle(1, ObstacleType.CAR, shape, initial,
                           TrajectoryPrediction(Trajectory(1, [final]), shape))


def _generator(config, network):
    generator = TerminalAwareTrafficGenerator(config=config)
    generator._matching_network = network
    generator._route_matchers = {}
    generator.route_matching_diagnostics = {}
    return generator


@pytest.mark.parametrize("start,finish,downstream", [(.1, 5., False), (5., 9.9, True)],
                         ids=["terminal-source", "terminal-sink"])
def test_terminal_source_and_sink_keep_mapped_road(tmp_path, start, finish, downstream):
    network = _network(tmp_path)
    config = ResimulationTrafficGeneratorConfig(extend_routes_upstream_junction=True,
                                                extend_routes_downstream_junction=downstream)
    before = asdict(config)
    generator = _generator(config, network)
    route = generator._get_route_for_dynamic_obstacle(_obstacle(start, finish), network)
    assert [edge.getID() for edge in route] == ["road"]
    assert generator._config is config
    assert asdict(config) == before
    # These real source/sink geometries reproduce the pinned max(empty) defects.
    with pytest.raises(ValueError, match="max.*empty sequence"):
        UnsafeResimulationTrafficGenerator(config=config)._get_route_for_dynamic_obstacle(
            _obstacle(start, finish), network
        )


def test_normal_junction_extensions_match_pinned_upstream(tmp_path):
    network = _network(tmp_path, continuations=True)
    config = ResimulationTrafficGeneratorConfig(extend_routes_upstream_junction=True,
                                                extend_routes_downstream_junction=True)
    before = asdict(config)
    obstacle = _obstacle(.1, 9.9)
    route = _generator(config, network)._get_route_for_dynamic_obstacle(obstacle, network)
    original = UnsafeResimulationTrafficGenerator(config=config)._get_route_for_dynamic_obstacle(obstacle, network)
    assert [edge.getID() for edge in route] == [edge.getID() for edge in original] == ["before", "road", "after"]
    assert asdict(config) == before


def test_downstream_only_can_extend_a_normal_junction(tmp_path):
    network = _network(tmp_path, continuations=True)
    config = ResimulationTrafficGeneratorConfig(extend_routes_downstream_junction=True)
    before = asdict(config)
    route = _generator(config, network)._get_route_for_dynamic_obstacle(
        _obstacle(5., 9.9), network
    )
    assert [edge.getID() for edge in route] == ["road", "after"]
    assert asdict(config) == before
