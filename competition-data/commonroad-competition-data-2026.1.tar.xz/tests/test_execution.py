"""Direct planning, repeated source submissions, failure reporting, and SUMO qualification."""

import shutil
import sys
import zipfile
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

import libsumo
import numpy as np
import pytest
import SMP
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.solution import CostFunction

from planner.runtime.evaluation import describe_result, evaluate_scenario
from planner.runtime.execution import run_spec
from legacy_scenarios import introductory_scenarios, reactive_scenarios
from planner.spec import PlannerSpec, reactive_spec, smp_spec
from planner.runtime.submission import DEFAULT_SUBMISSION, package_submission
from test_simulation import StraightPlanner
import planner.__main__ as cli


@pytest.mark.parametrize(
    "body,status,message",
    [
        ("return None", "invalid_output", "must return"),
        ('raise RuntimeError("intentional failure")', "planner_error", "intentional failure"),
        ('raise NoPathFound("no route")', "no_path", "no route"),
    ],
)
def test_planner_failures_and_simulator_cleanup(tmp_path, body, status, message):
    (tmp_path / "student_planner.py").write_text(
        "from planner.common.errors import NoPathFound\nfrom planner.spec import PlannerSpec\n\n"
        "class StudentPlanner:\n    def plan(self, scenario, problem):\n        "
        + body
        + "\n\ndef create_planner():\n    return PlannerSpec(StudentPlanner())\n"
    )
    result = evaluate_scenario(introductory_scenarios()[0], tmp_path)
    assert result.status == status
    assert message in result.message
    assert not libsumo.isLoaded()
    assert run_spec(introductory_scenarios()[0], reactive_spec()).valid


def test_notebook_local_planner_runs_in_the_calling_process():
    calls = []

    class NotebookPlanner(StraightPlanner):
        def plan(self, scenario, problem):
            calls.append(problem.initial_state.time_step)
            return super().plan(scenario, problem)

    result = run_spec(introductory_scenarios()[0], PlannerSpec(NotebookPlanner()))
    assert result.valid
    assert calls == list(range(20))


def test_submission_requires_create_planner(tmp_path):
    (tmp_path / "student_planner.py").write_text(
        "class StudentPlanner:\n    def plan(self, scenario, problem):\n        return None\n"
    )
    result = evaluate_scenario(introductory_scenarios()[0], tmp_path)
    assert result.status == "planner_error"
    assert "create_planner" in result.message
    assert not libsumo.isLoaded()


@pytest.mark.parametrize("factory", [smp_spec, reactive_spec])
def test_reusing_a_spec_resets_scenario_state(factory):
    spec = factory()
    first = run_spec(introductory_scenarios()[0], spec)
    calls = [item["time_step"] for item in first.diagnostics]
    second = run_spec(introductory_scenarios()[0], spec)
    assert first.valid and second.valid
    assert [item["time_step"] for item in second.diagnostics] == calls
    assert [item["time_step"] for item in first.diagnostics] == calls


def test_reactive_essen_preserves_traffic_motion(capfd):
    result = run_spec(reactive_scenarios()[0], reactive_spec())
    assert "Warning:" not in capfd.readouterr().err
    assert result.valid
    assert len(result.diagnostics) > 1
    assert len(result.scenario.dynamic_obstacles) == 7
    for actor in result.scenario.dynamic_obstacles:
        # Each car remains present beyond the opening two seconds. Later route
        # arrivals were checked separately against SUMO's arrival events.
        last = actor.prediction.final_time_step
        assert last > 20
        states = [actor.state_at_time(step) for step in range(last + 1)]
        assert all(state is not None for state in states)
        for before, after in zip(states, states[1:]):
            heading = np.array([np.cos(before.orientation), np.sin(before.orientation)])
            assert np.dot(after.position - before.position, heading) >= -1e-6


def test_submission_helpers_reload_after_factory_failure(tmp_path):
    for name in ["first", "second"]:
        directory = tmp_path / name
        directory.mkdir()
        (directory / "helper.py").write_text(f'MESSAGE = "{name} submission"\n')
        source = "from helper import MESSAGE\nfrom planner.spec import PlannerSpec\n\n"
        if name == "first":
            source += "def create_planner():\n    raise RuntimeError(MESSAGE)\n"
        else:
            source += (
                "class StudentPlanner:\n    def plan(self, scenario, problem):\n"
                "        raise RuntimeError(MESSAGE)\n\n"
                "def create_planner():\n    return PlannerSpec(StudentPlanner())\n"
            )
        (directory / "student_planner.py").write_text(source)
        result = evaluate_scenario(introductory_scenarios()[0], directory)
        assert result.status == "planner_error"
        assert result.message == f"{name} submission"
    assert run_spec(introductory_scenarios()[0], smp_spec()).valid


@pytest.mark.parametrize("path", introductory_scenarios(), ids=lambda path: path.stem)
@pytest.mark.parametrize(
    "factory,interval", [(smp_spec, 5), (reactive_spec, 3)], ids=["smp", "reactive"]
)
def test_introductory_repeated_planning(path, factory, interval, capfd):
    result = run_spec(path, factory())
    captured = capfd.readouterr()
    assert "Warning:" not in captured.err, captured.err  # SUMO warnings need investigation.
    assert result.valid and result.validation.feasible
    assert result.solution.planning_problem_solutions[0].cost_function == CostFunction.SM1
    assert np.isfinite(result.cost) and result.cost >= 0
    assert describe_result(result)["SM1"] == result.cost
    assert [call["time_step"] for call in result.diagnostics] == list(range(0, 20, interval))
    assert [call["executed_steps"] for call in result.diagnostics] == [
        min(interval, 20 - t) for t in range(0, 20, interval)
    ]
    trajectory = result.solution.planning_problem_solutions[0].trajectory
    problem = next(iter(result.planning_problems.planning_problem_dict.values()))
    assert problem.goal.is_reached(trajectory.final_state)
    original, _ = CommonRoadFileReader(str(path)).open()
    assert {o.obstacle_id for o in original.static_obstacles} == {
        o.obstacle_id for o in result.scenario.static_obstacles
    }
    # SUMO retains all actors present during the driven interval, with original IDs.
    expected = {
        o.obstacle_id for o in original.dynamic_obstacles if o.initial_state.time_step <= 20
    }
    assert expected <= {o.obstacle_id for o in result.scenario.dynamic_obstacles}


@pytest.mark.parametrize("kind", ["search", "arbitrary", "reactive"])
def test_multifile_bundle_outside_checkout(kind, tmp_path, monkeypatch):
    submission = Path(
        shutil.copytree(
            DEFAULT_SUBMISSION,
            tmp_path / "source",
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
    )
    entry = submission / "student_planner.py"
    if kind != "search":
        # Activate the commented option exactly as a participant would.
        option = 2 if kind == "reactive" else 3
        block = entry.read_text().split("\n# Option ")[option].split("\n", 1)[1]
        entry.write_text(
            "\n".join(line[2:] if line.startswith("# ") else "" for line in block.splitlines())
            + "\n"
        )
    if kind == "search":
        # An optional complete student source tree takes precedence over the pinned wheel.
        shutil.copytree(
            Path(SMP.__file__).parent,
            submission / "SMP",
            ignore=shutil.ignore_patterns("__pycache__"),
        )
        entry.write_text(
            entry.read_text()
            + '\nfrom pathlib import Path\nimport SMP\nassert Path(SMP.__file__).parent == Path(__file__).parent / "SMP"\n'
        )
    if kind == "arbitrary":
        (submission / "config.json").write_text('{"model": "models/weights.bin"}')
        (submission / "models").mkdir()
        (submission / "models/weights.bin").write_bytes(b"planner model data")
        (submission / "asset_motion.py").write_text(
            "import json\n"
            "from pathlib import Path\n"
            "from custom_planner import StudentPlanner as BasePlanner\n\n"
            "class StudentPlanner(BasePlanner):\n"
            "    def plan(self, scenario, problem):\n"
            "        root = Path(__file__).parent\n"
            "        config = json.loads((root / 'config.json').read_text())\n"
            "        assert (root / config['model']).read_bytes() == b'planner model data'\n"
            "        return super().plan(scenario, problem)\n"
        )
        entry.write_text(
            entry.read_text().replace(
                "from custom_planner import StudentPlanner", "from asset_motion import StudentPlanner"
            )
        )
    archive = package_submission(submission, tmp_path / "submission.zip")
    again = package_submission(submission, tmp_path / "again.zip")
    assert archive.read_bytes() == again.read_bytes()
    extracted = tmp_path / "extracted"
    with zipfile.ZipFile(archive) as zipped:
        zipped.extractall(extracted)
    monkeypatch.chdir(tmp_path)
    score = evaluate_scenario(introductory_scenarios()[0], extracted)
    assert score.passed, asdict(score)
    assert np.isfinite(score.score) and score.score >= 0


@pytest.mark.parametrize("malformed", ["<broken", "<commonRoad><invalid>"])
def test_cli_continues_batch_after_malformed_xml(tmp_path, monkeypatch, capsys, malformed):
    scenarios = tmp_path / "scenarios"
    scenarios.mkdir()
    (scenarios / "00-malformed.xml").write_text(malformed)
    path = introductory_scenarios()[0]
    shutil.copyfile(path, scenarios / path.name)
    result = SimpleNamespace(
        valid=True,
        validation=SimpleNamespace(feasible=True),
        cost=1.0,
        scoring_error=None,
        elapsed_seconds=0.0,
    )
    visited = []
    monkeypatch.setattr(cli, "run_submission", lambda *args: result)
    monkeypatch.setattr(cli, "export_result", lambda *args: visited.append(args[0]))
    monkeypatch.setattr(
        sys,
        "argv",
        ["planner", "--scenarios", str(scenarios), "--solutions", str(tmp_path / "results")],
    )
    assert cli.main() == 1
    assert visited == [result]
    assert "00-malformed.xml" in capsys.readouterr().out
