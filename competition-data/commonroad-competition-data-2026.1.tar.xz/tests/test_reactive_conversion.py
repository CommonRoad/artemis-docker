"""Cartesian/Frenet conversion preserves the reactive planner's actual initial state."""

import numpy as np
import pytest
from commonroad_rp.polynomial_trajectory import QuinticTrajectory
from commonroad_rp.reactive_planner import ReactivePlanner
from commonroad_rp.state import ReactivePlannerState
from commonroad_rp.trajectories import TrajectorySample
from commonroad_rp.utility.config import ReactivePlannerConfiguration
from commonroad_rp.utility.utils_coordinate_system import CoordinateSystem


def _quadratic(initial: np.ndarray, duration: float) -> QuinticTrajectory:
    """Make a polynomial with the supplied initial derivatives and constant acceleration."""
    position, velocity, acceleration = initial
    final = np.array(
        [
            position + velocity * duration + 0.5 * acceleration * duration**2,
            velocity + acceleration * duration,
            acceleration,
        ]
    )
    return QuinticTrajectory(delta_tau=duration, x_0=initial, x_d=final)


def _roundtrip(
    curvature: float, lateral: float, velocity: float
) -> tuple[ReactivePlannerState, ReactivePlannerState]:
    arclength = np.linspace(0.0, 60.0, 241)
    if curvature:
        reference = np.column_stack(
            (
                np.sin(curvature * arclength) / curvature,
                (1.0 - np.cos(curvature * arclength)) / curvature,
            )
        )
    else:
        reference = np.column_stack((arclength, np.zeros_like(arclength)))
    coordinates = CoordinateSystem(reference, preprocess_reference=False)

    # Only conversion and kinematic checking are needed; map/collision setup is unrelated.
    core = ReactivePlanner.__new__(ReactivePlanner)
    core.config = ReactivePlannerConfiguration()
    core.config.debug.multiproc = False
    core.dt = core.config.planning.dt
    core.N = 1
    core.vehicle_params = core.config.vehicle
    core._co = coordinates
    core._draw_traj_set = False
    core._low_vel_mode = velocity < core.config.planning.low_vel_mode_threshold
    core._infeasible_reason_dict = {}
    core._reset_statistics()
    initial = ReactivePlannerState(
        time_step=7,
        position=coordinates.convert_to_cartesian_coords(20.0, lateral),
        orientation=np.interp(20.0, coordinates.ref_pos, coordinates.ref_theta) + 0.18,
        velocity=velocity,
        acceleration=0.3,
        steering_angle=0.06,
        yaw_rate=velocity * np.tan(0.06) / core.vehicle_params.wheelbase,
    )
    core.x_0 = initial
    longitudinal, transverse = map(np.asarray, core._compute_initial_states(initial))
    sample = TrajectorySample(
        horizon=core.dt,
        dt=core.dt,
        trajectory_long=_quadratic(longitudinal, core.dt),
        # In low velocity mode these lateral derivatives are with respect to arclength.
        trajectory_lat=_quadratic(transverse, 1.0 if core._low_vel_mode else core.dt),
    )
    feasible, _ = core._check_kinematics([sample])
    assert feasible == [sample], core.infeasible_reason_dict
    regenerated = sample.cartesian.convert_to_rp_state_list(
        init_time_step=initial.time_step,
        init_yaw_rate=initial.yaw_rate,
        dt=core.dt,
        wheelbase=core.vehicle_params.wheelbase,
    )[0]
    return initial, regenerated


def _assert_same_initial_state(
    initial: ReactivePlannerState, regenerated: ReactivePlannerState
) -> None:
    assert regenerated.time_step == initial.time_step
    np.testing.assert_allclose(regenerated.position, initial.position, rtol=0.0, atol=1e-10)
    for attribute in ("orientation", "velocity", "acceleration", "steering_angle", "yaw_rate"):
        assert getattr(regenerated, attribute) == pytest.approx(
            getattr(initial, attribute), rel=1e-10, abs=1e-10
        ), attribute


@pytest.mark.parametrize(
    "curvature,lateral,velocity",
    [
        pytest.param(0.03, 2.0, 8.0, id="high-speed"),
        pytest.param(-0.03, -2.0, 2.0, id="low-speed"),
        pytest.param(0.03, 2.0, 0.0005, id="near-standstill"),
        pytest.param(-0.03, -2.0, 0.0, id="standstill"),
    ],
)
def test_curved_offset_initial_state_roundtrip(curvature, lateral, velocity):
    _assert_same_initial_state(*_roundtrip(curvature, lateral, velocity))


@pytest.mark.parametrize("velocity", [8.0, 2.0], ids=["high-speed", "low-speed"])
@pytest.mark.parametrize(
    "curvature,lateral",
    [(0.0, 2.0), (0.03, 0.0)],
    ids=["straight-reference", "on-reference"],
)
def test_straight_and_centered_initial_state_roundtrip(curvature, lateral, velocity):
    _assert_same_initial_state(*_roundtrip(curvature, lateral, velocity))
