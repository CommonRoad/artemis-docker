"""The preserved tutorial helpers must also work in browser-only containers."""

import base64
import io
from pathlib import Path
import re
import sys

import matplotlib
import pytest

pytest.importorskip("IPython")
pytest.importorskip("ipywidgets")

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tools.CR_Toolbox import CRToolbox
from tools.CR_Visualizer import CRVisualizer
from tools.specific_mp_renderer import SpecificMPRenderer
from planner.common.scenarios import ASSETS
from IPython import get_ipython
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output
from PIL import Image
from matplotlib.animation import FuncAnimation
from commonroad.common.solution import (
    CostFunction,
    PlanningProblemSolution,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.scenario.state import KSState
from commonroad.scenario.trajectory import Trajectory


def test_browser_visualization_without_reactive_planner_or_tk(tmp_path, monkeypatch):
    imported = set(sys.modules)
    root = Path(__file__).resolve().parents[1]
    monkeypatch.chdir(tmp_path)
    toolbox = CRToolbox(root)
    starter = ASSETS / "scenarios/public/DEU_ErlangenCRC26P-12_17300_I-1.xml"
    scenario, problems = toolbox.extract_scenario(starter)
    assert str(scenario.scenario_id) == starter.stem
    assert problems.planning_problem_dict
    viewer = CRVisualizer(root)
    viewer.visualize_benchmark(starter, show_ref_path=True)
    widget = viewer.visualize_driving_states_others(starter, 1)
    assert widget is not None
    assert matplotlib.get_backend().lower() == "agg"
    assert "tkinter" not in sys.modules
    assert not any(name.startswith("commonroad_rp") for name in set(sys.modules) - imported)


def test_notebook_map_and_slider_publish_png_with_agg():
    existing_shell = get_ipython()
    if existing_shell is None:
        InteractiveShell.instance()
    unrelated = plt.figure()
    viewer = CRVisualizer()
    starter = ASSETS / "scenarios/public/DEU_ErlangenCRC26P-12_17300_I-1.xml"
    control = None
    try:
        with capture_output() as map_output:
            viewer.visualize_benchmark(starter)
        with capture_output() as slider_output:
            control = viewer.visualize_driving_states_others(starter, 1)
        images = [
            output.data["image/png"]
            for captured in (map_output, slider_output)
            for output in captured.outputs
            if "image/png" in output.data
        ]
        assert len(images) == 2
        for data in images:
            with Image.open(io.BytesIO(base64.b64decode(data))) as image:
                assert image.format == "PNG"
                assert image.width > 100 and image.height > 100
        assert plt.get_fignums() == [unrelated.number]
        assert matplotlib.get_backend().lower() == "agg"
    finally:
        if control is not None:
            control.close()
        plt.close(unrelated)
        if existing_shell is None:
            InteractiveShell.clear_instance()


def test_cost_helper_propagates_file_errors(tmp_path):
    with pytest.raises(OSError, match="missing.xml"):
        CRToolbox(tmp_path).evaluate_cost("missing.xml", "solution.xml")


def test_animation_controls_work_without_external_fonts(monkeypatch):
    scenario, problems = CRToolbox().extract_scenario(
        ASSETS / "scenarios/public/DEU_ErlangenCRC26P-12_17300_I-1.xml"
    )
    problem = next(iter(problems.planning_problem_dict.values()))
    initial = problem.initial_state
    states = [
        KSState(
            position=initial.position.copy(),
            velocity=initial.velocity,
            orientation=initial.orientation,
            steering_angle=0.0,
            time_step=step,
        )
        for step in range(2)
    ]
    solution = Solution(
        scenario.scenario_id,
        [PlanningProblemSolution(
            problem.planning_problem_id,
            VehicleModel.KS,
            VehicleType.FORD_ESCORT,
            CostFunction.SM1,
            Trajectory(0, states),
        )],
    )
    original = FuncAnimation.to_jshtml
    generated = []

    def capture_html(animation):
        generated.append(original(animation))
        return generated[-1]

    monkeypatch.setattr(FuncAnimation, "to_jshtml", capture_html)
    html = CRVisualizer.animate_scenario(scenario, problems, solution).data
    assert "http://" not in html and "https://" not in html
    assert 'class="fa ' not in html
    buttons = re.findall(r"<button\b[^>]*>(.*?)</button>", html, re.DOTALL)
    assert [button.strip() for button in buttons] == [
        "−", "First", "Prev", "Back", "Pause", "Play", "Next", "Last", "+"
    ]
    # Keep the playback handlers, frame data, slider and radio controls unchanged.
    assert re.findall(r"<script\b.*?</script>", html, re.DOTALL) == re.findall(
        r"<script\b.*?</script>", generated[0], re.DOTALL
    )
    assert re.findall(r"<input\b[^>]*>", html, re.DOTALL) == re.findall(
        r"<input\b[^>]*>", generated[0], re.DOTALL
    )


@pytest.mark.parametrize("fig_size,expected", [(None, [16, 9]), ([6, 3], [6, 3])])
@pytest.mark.parametrize("ego_count", [1, 2])
def test_video_renderer_defaults_and_figure_size(tmp_path, monkeypatch, fig_size, expected, ego_count):
    scenario, _ = CRToolbox().extract_scenario(
        ASSETS / "scenarios/public/DEU_ErlangenCRC26P-12_17300_I-1.xml"
    )

    def render_first_frame(animation, *args, **kwargs):
        # Exercise real drawing while keeping this default-argument check independent of ffmpeg.
        animation._init_draw()
        animation._draw_next_frame(0, blit=False)

    monkeypatch.setattr(FuncAnimation, "save", render_first_frame)
    fig = plt.figure()
    renderer = SpecificMPRenderer()
    try:
        renderer.create_specific_video(
            [scenario],
            scenario.dynamic_obstacles[:ego_count],
            end_time_step=1,
            file_path=str(tmp_path / "preview.mp4"),
            fig_size=fig_size,
            progress=False,
        )
        assert renderer.f.get_size_inches().tolist() == expected
    finally:
        plt.close(fig)
