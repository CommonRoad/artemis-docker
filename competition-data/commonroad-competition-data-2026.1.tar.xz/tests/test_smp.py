"""Compatibility checks at the boundary around the unchanged search framework."""

from copy import deepcopy
from dataclasses import replace

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.scenario.state import CustomState, KSState
from SMP.motion_planner import plot_config
from SMP.motion_planner.search_algorithms.best_first_search import (
    AStarSearch,
    GreedyBestFirstSearch,
    UniformCostSearch,
)
from SMP.motion_planner.search_algorithms.depth_limited_search import DepthLimitedSearch
from SMP.motion_planner.search_algorithms.sequential_search import BreadthFirstSearch, DepthFirstSearch

from planner.common.errors import IncompatibleState, InvalidPlan, NoPathFound
from planner.common.prediction import predict_observations, relative_problem, search_horizon
from legacy_scenarios import introductory_scenarios
from planner.algorithms.smp import assert_same_state, center_trajectory, SMPPlanner
from planner.algorithms.smp_automaton import ExactStateAutomaton
from planner.spec import smp_spec


@pytest.fixture
def example():
    scenario, problems = CommonRoadFileReader(str(introductory_scenarios()[0])).open()
    return scenario, next(iter(problems.planning_problem_dict.values()))


def test_prediction_uses_current_state_only_and_covers_rounded_horizon(example):
    scenario, problem = example
    original = deepcopy(scenario)
    problem.initial_state.time_step = 7
    problem.goal.state_list[0].time_step = Interval(10, 38)
    horizon = search_horizon(problem)
    assert horizon == 35
    predicted = predict_observations(scenario, 7, horizon)
    for obstacle in predicted.dynamic_obstacles:
        observed = original.obstacle_by_id(obstacle.obstacle_id).state_at_time(7)
        assert obstacle.prediction.final_time_step == 35
        delta = (
            3.5
            * observed.velocity
            * np.array([np.cos(observed.orientation), np.sin(observed.orientation)])
        )
        np.testing.assert_allclose(obstacle.state_at_time(35).position, observed.position + delta)
    assert len(predicted.static_obstacles) == len(original.static_obstacles)
    relative = relative_problem(problem, 0.18)
    assert relative.initial_state.time_step == 0
    assert relative.initial_state.steering_angle == 0.18
    assert relative.goal.state_list[0].time_step == Interval(3, 31)
    assert problem.initial_state.time_step == 7
    assert problem.goal.state_list[0].time_step == Interval(10, 38)


def test_future_departures_excluded_and_stationary_actors_preserved(example):
    scenario, _ = example
    actor = scenario.dynamic_obstacles[0]
    actor.initial_state.velocity = 0.0
    actor.prediction = None
    future = deepcopy(actor)
    future._obstacle_id = scenario.generate_object_id()
    future.initial_state.time_step = 5
    scenario.add_objects(future)
    predicted = predict_observations(scenario, 0, 10)
    assert predicted.obstacle_by_id(future.obstacle_id) is None
    stationary = predicted.obstacle_by_id(actor.obstacle_id)
    np.testing.assert_array_equal(
        stationary.state_at_time(10).position, actor.initial_state.position
    )


def test_exact_grid_and_finite_successors(example):
    scenario, problem = example
    automaton = SMPPlanner()._automaton(scenario.scenario_id)
    view = ExactStateAutomaton(automaton, 10)
    root = view.create_initial_motion_primitive(problem)
    assert root.list_successors
    assert all(not p2.list_successors for p in root.list_successors for p2 in p.list_successors)
    assert any(p.list_successors for p in automaton.list_primitives)
    assert all(p.primitive in automaton.list_primitives for p in root.list_successors)
    problem.initial_state.steering_angle = 0.001
    with pytest.raises(IncompatibleState, match="steering"):
        view.create_initial_motion_primitive(problem)
    assert problem.initial_state.steering_angle == 0.001


def test_coordinates_duplicate_boundaries_and_absolute_time():
    axle = 1.42
    states = [
        KSState(
            position=np.array([float(i), 2.0]),
            orientation=0.4,
            velocity=4.0,
            steering_angle=0.18,
            time_step=i,
        )
        for i in range(6)
    ]
    result = center_trajectory([states[:4], states[3:]], axle, 12)
    assert [s.time_step for s in result.state_list] == list(range(12, 18))
    for original, converted in zip(states, result.state_list):
        np.testing.assert_allclose(
            converted.position - axle * np.array([np.cos(0.4), np.sin(0.4)]), original.position
        )
    states[4].time_step = 9
    with pytest.raises(InvalidPlan, match="gap"):
        center_trajectory([states], axle, 0)


def test_steering_recovery_and_reset(example):
    scenario, problem = example
    planner = SMPPlanner()
    first = planner.plan(scenario, problem)
    end = first.final_state
    # Exercise recovery of nonzero steering independently from a straight-road search.
    remembered = deepcopy(end)
    remembered.steering_angle = 0.18
    key = (str(scenario.scenario_id), problem.planning_problem_id)
    planner._endpoints[key] = remembered
    current = deepcopy(problem.initial_state)
    for attr in ("position", "velocity", "orientation", "time_step"):
        setattr(current, attr, deepcopy(getattr(end, attr)))
    assert not hasattr(current, "steering_angle")
    assert_same_state(remembered, current)
    current.position[0] += 0.01
    with pytest.raises(IncompatibleState):
        assert_same_state(remembered, current)
    planner.reset()
    assert planner._endpoints == {} and planner.diagnostics == []


def test_partial_final_primitive_and_nonzero_start(example):
    scenario, problem = example
    planner = SMPPlanner()
    first = planner.plan(scenario, problem)
    target = deepcopy(first.state_list[2])
    # Same physical problem at absolute time 10, with a goal on step 13.
    problem.initial_state.time_step = 10
    problem.goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(0.1, 0.1, center=target.position), time_step=Interval(13, 13)
            )
        ]
    )
    # Remove traffic for this state/time unit check; interactive qualification uses all actors.
    scenario.remove_obstacle(list(scenario.dynamic_obstacles))
    planner.reset()
    trajectory = planner.plan(scenario, problem)
    assert [s.time_step for s in trajectory.state_list] == [11, 12, 13]
    assert problem.goal.is_reached(trajectory.final_state)
    assert planner.diagnostics[-1]["horizon_steps"] == 5


def test_profiles_and_expired_goal(example):
    spec = smp_spec()
    spec.settings = replace(spec.settings, replanning_interval=1)
    with pytest.raises(ValueError, match="interval 5"):
        spec.validate()
    _, problem = example
    problem.initial_state.time_step = problem.goal.state_list[0].time_step.end
    with pytest.raises(NoPathFound, match="expired"):
        search_horizon(problem)


def test_replanning_supplies_recovered_steering_to_unchanged_constructor(example):
    scenario, problem = example
    planner = SMPPlanner()
    end = deepcopy(planner.plan(scenario, problem).final_state)
    # A compatible nonzero grid angle can be lost by SUMO's InitialState conversion.
    steering = next(
        p.state_initial.steering_angle
        for p in planner._automaton(scenario.scenario_id).list_primitives
        if p.state_initial.velocity == end.velocity and abs(p.state_initial.steering_angle) > 0.01
    )
    end.steering_angle = steering
    planner._endpoints[(str(scenario.scenario_id), problem.planning_problem_id)] = end
    for name in ("position", "velocity", "orientation", "time_step"):
        setattr(problem.initial_state, name, deepcopy(getattr(end, name)))

    class ObservedConstructor(Exception):
        pass

    class InspectSearch:
        def __init__(self, observed, relative, automaton, **kwargs):
            assert relative.initial_state.time_step == 0
            assert relative.initial_state.steering_angle == steering
            root = automaton.create_initial_motion_primitive(relative)
            assert all(
                abs(p.state_initial.steering_angle - steering) < 1e-6 for p in root.list_successors
            )
            raise ObservedConstructor()

    planner.planner_class = InspectSearch
    with pytest.raises(ObservedConstructor):
        planner.plan(scenario, problem)


def test_invalid_search_output_and_no_path_have_distinct_errors(example):
    scenario, problem = example

    class InvalidSearch(AStarSearch):
        def execute_search(self):
            paths, primitives, status = super().execute_search()
            paths[-1][-1].orientation = np.nan
            return paths, primitives, status

    with pytest.raises(InvalidPlan, match="non-finite"):
        SMPPlanner(InvalidSearch).plan(scenario, problem)

    class EmptySearch(AStarSearch):
        def execute_search(self):
            return None, None, None

    with pytest.raises(NoPathFound):
        SMPPlanner(EmptySearch).plan(scenario, problem)


@pytest.mark.parametrize(
    "search_class",
    [
        BreadthFirstSearch,
        DepthFirstSearch,
        UniformCostSearch,
        GreedyBestFirstSearch,
        AStarSearch,
        DepthLimitedSearch,
    ],
)
def test_history_switch_preserves_search_paths_and_failures(example, search_class):
    scenario, problem = example
    problem.goal = GoalRegion([CustomState(time_step=Interval(5, 5))])
    automaton = SMPPlanner()._automaton(scenario.scenario_id)
    outcomes = []
    for record in (True, False):
        config = plot_config.StudentScriptPlotConfig(RECORD_HISTORY=record)
        search = search_class(
            deepcopy(scenario),
            relative_problem(problem, 0.0),
            ExactStateAutomaton(automaton, 5),
            plot_config=config,
        )
        paths, primitives, history = search.execute_search()
        assert paths
        assert bool(history) == record
        states = [
            [
                *state.position,
                state.orientation,
                state.velocity,
                state.steering_angle,
                state.time_step,
            ]
            for path in paths
            for state in path
        ]
        outcomes.append((states, [primitive.id for primitive in primitives[1:]]))
    np.testing.assert_array_equal(outcomes[0][0], outcomes[1][0])
    assert outcomes[0][1] == outcomes[1][1]

    search = search_class(
        deepcopy(scenario),
        relative_problem(problem, 0.0),
        ExactStateAutomaton(automaton, 5),
        plot_config=plot_config.StudentScriptPlotConfig(RECORD_HISTORY=False),
    )
    search.motion_primitive_initial.list_successors = []
    assert search.execute_search() == (None, None, [])


@pytest.mark.parametrize("legacy_constructor", [False, True])
def test_competition_search_does_not_record_history(example, monkeypatch, legacy_constructor):
    scenario, problem = example
    if legacy_constructor:

        class LegacyPlotConfig(plot_config.PlotConfig):
            def __init__(self, DO_PLOT=False):
                self.DO_PLOT = DO_PLOT

        monkeypatch.setattr(plot_config, "StudentScriptPlotConfig", LegacyPlotConfig)

    histories = []

    class ObservedSearch(AStarSearch):
        def execute_search(self):
            result = super().execute_search()
            histories.append(result[2])
            return result

    result = SMPPlanner(ObservedSearch).plan(scenario, problem)
    assert result.state_list
    assert histories == [[]]
    assert plot_config.DefaultPlotConfig.RECORD_HISTORY is True
