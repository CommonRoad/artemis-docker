"""Recorded valid drives exercise the route matcher's projection fallback."""

import json
from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.solution import CostFunction, VehicleType
from commonroad.scenario.state import KSState
from commonroad.scenario.trajectory import Trajectory
from commonroad_dc.costs.evaluation import CostFunctionEvaluator as UpstreamEvaluator

from legacy_scenarios import reactive_scenarios
from planner.common.scoring import CostFunctionEvaluator


@pytest.fixture(params=["search", "reactive"])
def drive(request):
    scenario, problems = CommonRoadFileReader(str(reactive_scenarios()[0])).open()
    problem = next(iter(problems.planning_problem_dict.values()))
    path = Path(__file__).with_name("fixtures") / f"essen_scoring_{request.param}.json"
    states = [
        KSState(**dict(row, position=np.array(row["position"])))
        for row in json.loads(path.read_text())
    ]
    return request.param, scenario, problem, Trajectory(0, states)


def test_recorded_valid_drives_receive_finite_sm1_without_modification(drive):
    kind, scenario, problem, trajectory = drive
    original = deepcopy(trajectory)
    assert problem.goal_reached(trajectory)[0]
    evaluator = CostFunctionEvaluator(CostFunction.SM1, VehicleType.BMW_320i)
    result = evaluator.evaluate_pp_solution(scenario, problem, trajectory)
    assert np.isfinite(result.total_costs) and result.total_costs > 0
    if kind == "reactive":
        previous = UpstreamEvaluator(CostFunction.SM1, VehicleType.BMW_320i)
        assert (
            result.total_costs
            == previous.evaluate_pp_solution(scenario, problem, trajectory).total_costs
        )
    for before, after in zip(original.state_list, trajectory.state_list):
        for name in before.attributes:
            np.testing.assert_array_equal(getattr(before, name), getattr(after, name))


def test_unmatchable_drive_remains_an_error(drive):
    _, scenario, problem, trajectory = drive
    trajectory.translate_rotate(np.array([10000.0, 10000.0]), 0.0)
    evaluator = CostFunctionEvaluator(CostFunction.SM1, VehicleType.BMW_320i)
    with pytest.raises((RuntimeError, ValueError, AssertionError, IndexError)):
        evaluator.evaluate_pp_solution(scenario, problem, trajectory)
