"""Collision checking also handles actors with only their initial occupancy."""

from copy import deepcopy

import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.common.solution import (
    CostFunction,
    PlanningProblemSolution,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.geometry.shape import Rectangle
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType
from commonroad.scenario.state import InitialState, KSState
from commonroad.scenario.trajectory import Trajectory

from legacy_scenarios import introductory_scenarios
from simulation.solution_check import CollisionException, obstacle_collision


@pytest.mark.parametrize(
    "offset,actor_time,collision", [(0, 0, True), (50, 0, False), (0, 50, False)]
)
def test_single_occupancy_preserves_space_and_time(offset, actor_time, collision):
    scenario, problems = CommonRoadFileReader(str(introductory_scenarios()[0])).open()
    scenario.remove_obstacle(list(scenario.obstacles))
    problem = next(iter(problems.planning_problem_dict.values()))
    current = problem.initial_state
    initial = KSState(
        position=current.position.copy(),
        orientation=current.orientation,
        velocity=current.velocity,
        steering_angle=0.0,
        time_step=0,
    )
    future = deepcopy(initial)
    future.time_step = 1
    future.position += (
        current.velocity
        * scenario.dt
        * np.array([np.cos(current.orientation), np.sin(current.orientation)])
    )
    trajectory = Trajectory(0, [initial, future])
    solution = Solution(
        scenario.scenario_id,
        [
            PlanningProblemSolution(
                planning_problem_id=problem.planning_problem_id,
                vehicle_type=VehicleType.BMW_320i,
                vehicle_model=VehicleModel.KS,
                cost_function=CostFunction.SM1,
                trajectory=trajectory,
            )
        ],
    )
    scenario.add_objects(
        DynamicObstacle(
            scenario.generate_object_id(),
            ObstacleType.CAR,
            Rectangle(4.5, 1.8),
            InitialState(
                position=current.position + [offset, 0],
                orientation=current.orientation,
                velocity=0.0,
                time_step=actor_time,
            ),
        )
    )
    if collision:
        with pytest.raises(CollisionException):
            obstacle_collision(scenario, problems, solution)
    else:
        assert not obstacle_collision(scenario, problems, solution)
