"""SUMO histories must collide at their actual absolute timestamps."""

from copy import deepcopy

import numpy as np
import pytest
from commonroad.common.solution import (
    CostFunction,
    PlanningProblemSolution,
    Solution,
    VehicleModel,
    VehicleType,
)
from commonroad.geometry.shape import Rectangle
from commonroad.planning.planning_problem import PlanningProblemSet
from commonroad.prediction.prediction import TrajectoryPrediction
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType
from commonroad.scenario.scenario import Scenario
from commonroad.scenario.state import InitialState, KSState
from commonroad.scenario.trajectory import Trajectory
from commonroad_dc.collision.collision_detection.pycrcc_collision_dispatch import (
    create_collision_object,
)

from simulation.solution_check import CollisionException, obstacle_collision
from simulation.traffic import remove_initial_state_from_predictions


def recorded_actor(start, positions, *, duplicate_initial=True):
    states = [
        InitialState(position=np.array([x, 0.0]), orientation=0.0, velocity=0.0, time_step=t)
        for t, x in enumerate(positions, start)
    ]
    actor = DynamicObstacle(100, ObstacleType.CAR, Rectangle(4.5, 1.8), states[0])
    prediction_states = states if duplicate_initial else states[1:]
    if prediction_states:
        actor.prediction = TrajectoryPrediction(
            Trajectory(prediction_states[0].time_step, prediction_states), actor.obstacle_shape
        )
        # Exercise normalization after another consumer has cached the geometry.
        assert actor.prediction.occupancy_set
    return actor


@pytest.mark.parametrize("start", [0, 7])
@pytest.mark.parametrize("ego_x,collision", [(0.0, True), (20.0, False)])
def test_collision_uses_current_position_instead_of_previous_step(start, ego_x, collision):
    scenario = Scenario(0.1)
    actor = recorded_actor(start, [20.0, 0.0, 20.0])
    scenario.add_objects(actor)
    trajectory = Trajectory(
        start,
        [
            KSState(
                position=np.array([x, 0.0]),
                orientation=0.0,
                velocity=0.0,
                steering_angle=0.0,
                time_step=t,
            )
            for t, x in enumerate([-50.0, ego_x, 50.0], start)
        ],
    )
    solution = Solution(
        scenario.scenario_id,
        [
            PlanningProblemSolution(
                1, VehicleModel.KS, VehicleType.BMW_320i, CostFunction.SM1, trajectory
            )
        ],
    )
    remove_initial_state_from_predictions(scenario)
    converted = create_collision_object(actor)
    assert converted.time_start_idx() == start
    assert converted.time_end_idx() == start + 2
    for t in range(start, start + 3):
        bounds = converted.obstacle_at_time(t).getAABB()
        np.testing.assert_array_equal(
            [(bounds.min_x() + bounds.max_x()) / 2, (bounds.min_y() + bounds.max_y()) / 2],
            actor.state_at_time(t).position,
        )
    if collision:
        with pytest.raises(CollisionException, match="scenario obstacles"):
            obstacle_collision(scenario, PlanningProblemSet(), solution)
    else:
        assert not obstacle_collision(scenario, PlanningProblemSet(), solution)


@pytest.mark.parametrize("start", [0, 7])
@pytest.mark.parametrize("duplicate_initial", [False, True])
@pytest.mark.parametrize("positions", [[20.0], [20.0, 21.0, 22.0]])
def test_normalization_preserves_initial_only_and_future_states(
    start, duplicate_initial, positions
):
    scenario = Scenario(0.1)
    actor = recorded_actor(start, positions, duplicate_initial=duplicate_initial)
    scenario.add_objects(actor)
    original = deepcopy(actor)
    remove_initial_state_from_predictions(scenario)
    remove_initial_state_from_predictions(scenario)
    assert actor.initial_state == original.initial_state
    for t in range(start - 1, start + len(positions) + 1):
        if t < 0:
            continue
        assert actor.state_at_time(t) == original.state_at_time(t)
        assert actor.occupancy_at_time(t) == original.occupancy_at_time(t)
    converted = create_collision_object(actor)
    assert converted.time_start_idx() == start
    assert converted.time_end_idx() == start + len(positions) - 1
    if len(positions) == 1:
        assert actor.prediction is None
    else:
        assert [o.time_step for o in actor.prediction.occupancy_set] == [start + 1, start + 2]
