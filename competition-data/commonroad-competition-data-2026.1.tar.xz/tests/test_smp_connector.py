"""Continuous-speed starts must remain feasible, collision-checked parts of the search."""

from copy import deepcopy
from pathlib import Path
import shutil

import numpy as np
import pytest
import SMP
from commonroad.common.util import Interval
from commonroad.geometry.shape import Rectangle
from commonroad.planning.goal import GoalRegion
from commonroad.planning.planning_problem import PlanningProblem
from commonroad.scenario.lanelet import Lanelet
from commonroad.scenario.obstacle import ObstacleType, StaticObstacle
from commonroad.scenario.scenario import Scenario
from commonroad.scenario.state import CustomState, InitialState, KSState
from commonroad_dc.feasibility.feasibility_checker import trajectory_feasibility
from commonroad_dc.feasibility.vehicle_dynamics import VehicleDynamics

from planner.common.trajectory import assert_same_state
from planner.common.errors import IncompatibleState, NoPathFound
from planner.algorithms.smp import SMPConfig, SMPPlanner, center_trajectory
from planner.algorithms.smp_automaton import ExactStateAutomaton
from planner.runtime.submission import load_submission


@pytest.fixture(scope="module")
def automaton():
    return SMPPlanner()._automaton("DEU_Essen-7_3_I-1")


@pytest.fixture
def straight_road():
    scenario = Scenario(dt=0.1)
    scenario.add_objects(
        Lanelet(
            left_vertices=np.array([[0.0, 3.0], [80.0, 3.0]]),
            center_vertices=np.array([[0.0, 0.0], [80.0, 0.0]]),
            right_vertices=np.array([[0.0, -3.0], [80.0, -3.0]]),
            lanelet_id=1,
        )
    )
    initial = InitialState(
        position=np.array([10.0, 0.0]),
        velocity=13.0844,
        orientation=0.0,
        acceleration=0.0,
        yaw_rate=0.0,
        slip_angle=0.0,
        time_step=10,
    )
    goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(2.0, 1.0, center=np.array([22.5, 0.0])),
                velocity=Interval(11.9, 12.1),
                time_step=Interval(20, 20),
            )
        ]
    )
    return scenario, PlanningProblem(1, initial, goal)


@pytest.mark.parametrize("speed,steering", [(13.0844, 0.0), (5.0844, 1.066 / 6)])
def test_connector_dynamics_coordinates_and_successors(automaton, straight_road, speed, steering):
    _, problem = straight_road
    problem.initial_state.velocity = speed
    problem.initial_state.steering_angle = steering
    original = deepcopy(problem.initial_state)
    source_ids = [p.id for p in automaton.list_primitives]
    source_edges = [
        [p.id for p in primitive.list_successors] for primitive in automaton.list_primitives
    ]
    view = ExactStateAutomaton(automaton, 10)
    root = view.create_initial_motion_primitive(problem)
    targets = [12.0, 14.0] if speed > 10 else [4.0, 6.0]
    assert [p.state_final.velocity for p in root.list_successors] == pytest.approx(targets)
    dynamics = VehicleDynamics.KS(automaton.type_vehicle)
    axle = dynamics.parameters.b

    for connector, target in zip(root.list_successors, targets):
        assert connector.state_initial.velocity == speed
        assert connector.state_initial.steering_angle == steering
        assert connector.id not in source_ids
        # Attach at a rotated, translated rear axle at a nonzero absolute time.
        rear_start = KSState(
            position=np.array([20.0, 30.0]),
            orientation=0.4,
            velocity=speed,
            steering_angle=steering,
            time_step=10,
        )
        attached = connector.attach_trajectory_to_state(rear_start)
        trajectory = center_trajectory([[rear_start] + attached], axle, 0)
        assert [s.time_step for s in trajectory.state_list] == list(range(10, 16))
        assert trajectory_feasibility(trajectory, dynamics, 0.1)[0]
        np.testing.assert_allclose(
            trajectory.state_list[0].position,
            rear_start.position + axle * np.array([np.cos(0.4), np.sin(0.4)]),
        )
        for successor in connector.list_successors:
            assert successor.primitive in automaton.list_primitives
            assert successor.state_initial.velocity == target
            assert successor.state_initial.steering_angle == pytest.approx(steering)
            assert not successor.list_successors  # Connector plus one primitive fills the horizon.
        successor = connector.list_successors[0]
        continuation = successor.attach_trajectory_to_state(attached[-1])
        joined = center_trajectory(
            [[rear_start] + attached, [attached[-1]] + continuation], axle, 0
        )
        assert [s.time_step for s in joined.state_list] == list(range(10, 21))
        assert trajectory_feasibility(joined, dynamics, 0.1)[0]

    assert_same_state(problem.initial_state, original)
    assert [p.id for p in automaton.list_primitives] == source_ids
    assert [
        [p.id for p in primitive.list_successors] for primitive in automaton.list_primitives
    ] == source_edges


def test_replanning_after_connector_preserves_actual_start(straight_road):
    scenario, problem = straight_road
    original = deepcopy(problem)
    planner = SMPPlanner()
    first = planner.plan(scenario, problem)
    assert first.initial_time_step == 11
    assert first.final_state.time_step == 15
    assert any(abs(first.final_state.velocity - speed) < 1e-6 for speed in (12.0, 14.0))
    assert problem.initial_state.velocity == original.initial_state.velocity
    np.testing.assert_array_equal(problem.initial_state.position, original.initial_state.position)
    assert problem.goal.state_list[0].time_step == original.goal.state_list[0].time_step

    # Simulate SUMO's loss of steering while retaining the executed state.
    for name in ("position", "orientation", "velocity", "time_step"):
        setattr(problem.initial_state, name, deepcopy(getattr(first.final_state, name)))
    second = planner.plan(scenario, problem)
    assert problem.goal.is_reached(second.final_state)
    assert [d["horizon_steps"] for d in planner.diagnostics] == [10, 5]
    assert [d["executed_steps"] for d in planner.diagnostics] == [5, 5]


def test_goal_can_end_within_connector(straight_road):
    scenario, problem = straight_road
    acceleration = (12.0 - problem.initial_state.velocity) / 0.5
    x = 10.0 + problem.initial_state.velocity * 0.3 + 0.5 * acceleration * 0.3**2
    problem.goal = GoalRegion(
        [
            CustomState(
                position=Rectangle(0.01, 0.01, center=np.array([x, 0.0])),
                time_step=Interval(13, 13),
            )
        ]
    )
    planner = SMPPlanner()
    trajectory = planner.plan(scenario, problem)
    assert [s.time_step for s in trajectory.state_list] == [11, 12, 13]
    assert problem.goal.is_reached(trajectory.final_state)
    assert trajectory.final_state.velocity == pytest.approx(13.0844 + 0.3 * acceleration)
    assert planner.diagnostics[-1]["horizon_steps"] == 5


@pytest.mark.parametrize("speed,spacing,target", [(20.1, 2, 20.0), (16.1, 4, 16.0)])
def test_only_feasible_neighbor_is_offered(straight_road, speed, spacing, target):
    _, problem = straight_road
    problem.initial_state.velocity = speed
    automaton = SMPPlanner(config=SMPConfig(speed_spacing=spacing))._automaton("test")
    root = ExactStateAutomaton(automaton, 5).create_initial_motion_primitive(problem)
    # Above the grid only its edge is available. On the coarse grid, acceleration
    # toward 20 m/s is power-limited and cannot reach that endpoint in half a second.
    assert len(root.list_successors) == 1
    connector = root.list_successors[0]
    assert connector.state_initial.velocity == speed
    assert connector.state_final.velocity == pytest.approx(target)
    assert not connector.list_successors


def test_connector_uses_the_submitted_smp_class(straight_road, tmp_path):
    shutil.copytree(
        Path(SMP.__file__).parent,
        tmp_path / "SMP",
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    (tmp_path / "student_planner.py").write_text(
        "from my_search import StudentSearch\n"
        "from planner.spec import smp_spec\n"
        "def create_planner():\n"
        "    return smp_spec(StudentSearch)\n"
    )
    (tmp_path / "my_search.py").write_text(
        "from SMP.motion_planner.search_algorithms.best_first_search import AStarSearch\n"
        "from SMP.maneuver_automaton.motion_primitive import MotionPrimitive\n"
        "class StudentSearch(AStarSearch):\n"
        "    def execute_search(self):\n"
        "        for first in self.motion_primitive_initial.list_successors:\n"
        "            assert type(first.primitive) is MotionPrimitive\n"
        "        return super().execute_search()\n"
    )
    with load_submission(tmp_path) as spec:
        trajectory = spec.planner.plan(*straight_road)
        assert trajectory.final_state.time_step == 15


@pytest.mark.parametrize("failure", ["obstacle", "boundary", "unreachable_goal", "deadline"])
def test_connector_is_not_executed_without_a_complete_valid_path(straight_road, failure):
    scenario, problem = straight_road
    if failure == "obstacle":
        scenario.add_objects(
            StaticObstacle(
                2,
                ObstacleType.UNKNOWN,
                Rectangle(0.2, 6.0),
                InitialState(position=np.array([14.0, 0.0]), orientation=0.0, time_step=0),
            )
        )
    elif failure == "boundary":
        problem.initial_state.position[1] = 2.5
    elif failure == "unreachable_goal":
        problem.goal.state_list[0].position = Rectangle(2.0, 1.0, center=np.array([70.0, 0.0]))
    else:
        problem.goal.state_list[0].time_step = Interval(11, 11)
    planner = SMPPlanner()
    with pytest.raises(NoPathFound):
        planner.plan(scenario, problem)
    assert planner._endpoints == {}
    assert planner.diagnostics == []


@pytest.mark.parametrize(
    "speed,steering,message",
    [
        (100.0, 0.0, "No feasible"),
        (-0.1, 0.0, "nonnegative"),
        (np.nan, 0.0, "finite"),
        (5.1, 0.01, "steering"),
    ],
)
def test_unsupported_connector_states(automaton, straight_road, speed, steering, message):
    _, problem = straight_road
    problem.initial_state.velocity = speed
    problem.initial_state.steering_angle = steering
    with pytest.raises(IncompatibleState, match=message):
        ExactStateAutomaton(automaton, 10).create_initial_motion_primitive(problem)
