"""Connected full guides must outrank wrong-heading partial and greedy branches."""

import math
import xml.etree.ElementTree as ET

import numpy as np
import pytest
import sumolib
from commonroad.scenario.state import KSState
from commonroad_sumo.cr2sumo.traffic_generator.sumo_map_matcher import SumoMapMatcher

from simulation.route_matching import FullGuideMapMatcher


def _network(tmp_path, roads, connections, internals=()):
    root = ET.Element("net", version="1.20")
    ET.SubElement(root, "location", netOffset="0,0", convBoundary="-20,-20,40,20",
                  origBoundary="-20,-20,40,20", projParameter="!")
    nodes = {}
    for name, source, target, points, allowed in [*roads, *internals]:
        attrs = {"id": name}
        if source is None:
            attrs["function"] = "internal"
        else:
            attrs.update({"from": source, "to": target})
            nodes[source], nodes[target] = points[0], points[-1]
        edge = ET.SubElement(root, "edge", attrs)
        length = sum(math.dist(a, b) for a, b in zip(points, points[1:]))
        lane = {"id": name + "_0", "index": "0", "speed": "13.89", "length": str(length),
                "shape": " ".join(f"{x},{y}" for x, y in points)}
        if allowed:
            lane["allow"] = allowed
        ET.SubElement(edge, "lane", lane)
    for name, (x, y) in nodes.items():
        incoming = " ".join(edge + "_0" for edge, _, target, _, _ in roads if target == name)
        ET.SubElement(root, "junction", id=name, x=str(x), y=str(y), type="priority",
                      incLanes=incoming, intLanes="",
                      shape=f"{x-.5},{y-1} {x+.5},{y-1} {x+.5},{y+1} {x-.5},{y+1}")
    for source, target, via in connections:
        attrs = {"from": source, "to": target, "fromLane": "0", "toLane": "0",
                 "dir": "s", "state": "M"}
        if via:
            attrs["via"] = via
        ET.SubElement(root, "connection", attrs)
    path = tmp_path / "network.net.xml"
    ET.ElementTree(root).write(path)
    return sumolib.net.readNet(str(path), withInternal=True)


def _states(points):
    return [KSState(position=np.array(point, dtype=float), orientation=0., velocity=3.,
                    steering_angle=0., time_step=i) for i, point in enumerate(points)]


def test_wrong_heading_partial_route_cannot_win_by_ignoring_later_samples(tmp_path):
    net = _network(tmp_path, [
        ("opposite", "west", "east", [(5, 0), (-5, 0)], None),
        ("forward", "start", "finish", [(0, .8), (30, .8)], None),
    ], [])
    states = _states([(1, 0), (3, 0), (5, 0), (10, 0), (20, 0)])
    old = SumoMapMatcher(net, 5).map_trace([tuple(s.position) for s in states])
    assert [edge.getID() for edge in old] == ["opposite"]
    matched = FullGuideMapMatcher(net, "passenger", 5).match(states)
    assert matched.edges == ("forward",)
    assert matched.samples == len(states)
    assert matched.maximum_distance_m == pytest.approx(.8)
    assert matched.initial_heading_error_rad == pytest.approx(0)


def test_later_guide_evidence_selects_connected_branch(tmp_path):
    net = _network(tmp_path, [
        ("approach", "start", "junction", [(0, 0), (10, 0)], None),
        ("trap", "junction", "deadend", [(10, 0), (12, 0)], None),
        ("exit", "junction", "finish", [(10, 0), (12, .1), (20, .1)], None),
    ], [("approach", "trap", None), ("approach", "exit", None)])
    states = _states([(1, 0), (6, 0), (9.9, 0), (10.5, 0), (11.5, 0), (14, .1), (19, .1)])
    old = SumoMapMatcher(net, 5).map_trace([tuple(s.position) for s in states])
    assert [edge.getID() for edge in old] == ["approach", "trap"]
    first = FullGuideMapMatcher(net, "passenger", 5).match(states)
    second = FullGuideMapMatcher(net, "passenger", 5).match(states)
    assert first == second
    assert first.edges == ("approach", "exit")
    assert first.samples == len(states)


def _junction_network(tmp_path, internal_allowed=None):
    return _network(tmp_path, [
        ("before", "start", "join", [(-10, 0), (0, 0)], None),
        ("after", "join", "finish", [(1, 0), (10, 0)], None),
    ], [("before", "after", ":join_0_0"), (":join_0", "after", None)],
        internals=[(":join_0", None, None, [(0, 0), (1, 0)], internal_allowed)])


def test_internal_start_reconstructs_the_actual_incoming_movement(tmp_path):
    net = _junction_network(tmp_path)
    matched = FullGuideMapMatcher(net, "passenger", 5).match(_states([(.5, 0), (3, 0), (8, 0)]))
    assert matched.starts_inside_junction
    assert matched.edges == ("before", "after")
    assert matched.node_path == ("before", ":join_0_0", "after")
    assert matched.maximum_distance_m == 0


def test_connection_permissions_apply_to_the_internal_lane(tmp_path):
    net = _junction_network(tmp_path, internal_allowed="bus")
    states = _states([(-5, 0), (-1, 0), (.5, 0), (3, 0), (8, 0)])
    assert FullGuideMapMatcher(net, "bus", 5).match(states).edges == ("before", "after")
    with pytest.raises(ValueError, match="connected forward route"):
        FullGuideMapMatcher(net, "passenger", 5).match(states)


def test_vehicle_class_is_not_assumed_to_be_passenger(tmp_path):
    net = _network(tmp_path, [("cycleway", "start", "finish", [(0, 0), (10, 0)], "bicycle")], [])
    states = _states([(1, 0), (9, 0)])
    assert FullGuideMapMatcher(net, "bicycle", 5).match(states).edges == ("cycleway",)
    with pytest.raises(ValueError, match="class-permitted forward route"):
        FullGuideMapMatcher(net, "passenger", 5).match(states)


def test_zero_length_internal_connector_can_be_crossed_between_samples(tmp_path):
    net = _network(tmp_path, [
        ("before", "start", "join", [(10, 0), (0, 0)], None),
        ("after", "join", "finish", [(0, 0), (-10, 0)], None),
    ], [("before", "after", ":join_0_0"), (":join_0", "after", None)],
        internals=[(":join_0", None, None, [(0, 0), (0, 0)], None)])
    states = _states([(1, 0), (-1, 0)])
    for state in states:
        state.orientation = math.pi
    matched = FullGuideMapMatcher(net, "passenger", 5).match(states)
    assert matched.edges == ("before", "after")
    assert matched.node_path == ("before", ":join_0_0", "after")
    assert matched.maximum_distance_m == 0
    assert matched.initial_heading_error_rad == pytest.approx(0)
