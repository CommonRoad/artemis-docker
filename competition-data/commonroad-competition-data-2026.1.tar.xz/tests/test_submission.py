"""Planner assets travel with their source and contribute to its recorded identity."""

import hashlib
import json
import sys
import zipfile

import pytest

from planner.runtime.artifacts import submission_metadata
from planner.runtime.submission import load_submission, package_submission, submission_files


@pytest.fixture
def bundle(tmp_path):
    source = tmp_path / "source"
    (source / "assets").mkdir(parents=True)
    (source / "student_planner.py").write_text(
        "import json\n"
        "from pathlib import Path\n"
        "from types import SimpleNamespace\n"
        "from planner.spec import PlannerSpec\n\n"
        "def create_planner():\n"
        "    root = Path(__file__).parent\n"
        "    return PlannerSpec(SimpleNamespace(\n"
        "        config=json.loads((root / 'assets/config.json').read_text()),\n"
        "        weights=(root / 'json.bin').read_bytes(), json_module=json))\n"
    )
    (source / "assets/config.json").write_text('{"speed": 5}')
    (source / "json.bin").write_bytes(bytes(range(256)) * 4097)
    return source


def test_asset_bundle_roundtrip_and_import_identity(bundle, tmp_path, monkeypatch):
    before = submission_metadata(bundle)
    archive = package_submission(bundle, tmp_path / "submission.zip")
    assert archive.read_bytes() == package_submission(bundle, tmp_path / "again.zip").read_bytes()
    extracted = tmp_path / "extracted"
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.namelist() == ["assets/config.json", "json.bin", "student_planner.py"]
        zipped.extractall(extracted)
    assert submission_metadata(extracted) == before
    monkeypatch.chdir(tmp_path)
    with load_submission(extracted) as spec:
        assert spec.planner.config == {"speed": 5}
        assert spec.planner.weights == (bundle / "json.bin").read_bytes()
        # An asset named json.bin must not unload Python's json module.
        assert spec.planner.json_module is json
        assert sys.modules["json"] is json
    assert sys.modules["json"] is json


@pytest.mark.parametrize("filename", ["assets/config.json", "json.bin"])
def test_asset_content_and_path_affect_identity(bundle, filename):
    path = bundle / filename
    before = submission_metadata(bundle)
    path.write_bytes(path.read_bytes() + b" ")
    after_edit = submission_metadata(bundle)
    assert after_edit != before
    path.rename(path.with_name("renamed" + path.suffix))
    assert submission_metadata(bundle) != after_edit


def test_exclusions_do_not_enter_zip_or_identity(bundle, tmp_path):
    before = submission_metadata(bundle)
    for name in (
        ".git/config", ".vscode/settings.json", ".venv/bin/python", "env/bin/python",
        "assets/__pycache__/helper.pyc", ".pytest_cache/result", "build/model.bin",
        "dist/submission.zip", "outputs/scenario.xml", "solutions/solution.xml",
        "package.egg-info/PKG-INFO", "module.pyc", "editor.swp", "editor~", ".gitignore",
    ):
        path = bundle / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("excluded")
    # Ignored environments must not be traversed or rejected for their usual symlinks.
    (bundle / ".venv/bin/python-link").symlink_to(bundle / ".venv/bin/python")
    assert submission_metadata(bundle) == before
    with zipfile.ZipFile(package_submission(bundle, tmp_path / "bundle.zip")) as archive:
        assert archive.namelist() == ["assets/config.json", "json.bin", "student_planner.py"]


@pytest.mark.parametrize("kind", ["file", "directory", "broken"])
def test_submission_rejects_symlinks(bundle, tmp_path, kind):
    targets = {
        "file": bundle / "json.bin",
        "directory": bundle / "assets",
        "broken": tmp_path / "missing",
    }
    target = targets[kind]
    (bundle / "linked").symlink_to(target, target_is_directory=kind == "directory")
    with pytest.raises(ValueError, match="Symlinks are not supported"):
        package_submission(bundle, tmp_path / "submission.zip")


def test_zip_destination_must_be_outside_bundle(bundle):
    with pytest.raises(ValueError, match="outside the submission directory"):
        package_submission(bundle, bundle / "submission.zip")
    assert not (bundle / "submission.zip").exists()


def test_streamed_hash_preserves_existing_digest_format(bundle):
    expected = hashlib.sha256()
    for path in submission_files(bundle):
        expected.update(path.relative_to(bundle).as_posix().encode() + b"\0")
        expected.update(path.read_bytes() + b"\0")
    assert submission_metadata(bundle)["sha256"] == expected.hexdigest()
