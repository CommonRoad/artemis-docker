"""Initial background calibration preserves route intent and the physical state."""

from pathlib import Path
from copy import deepcopy
import xml.etree.ElementTree as ET
import subprocess

import libsumo
import numpy as np
import pytest
from commonroad.common.file_reader import CommonRoadFileReader
from commonroad.planning.planning_problem import PlanningProblemSet
from commonroad_sumo.simulation.interactive_simulation import InteractiveSumoSimulationWithMotionPlannerConfig
from commonroad_sumo.sumolib.sumo_project import SumoFileType
from planner.common.scenarios import ASSETS
from simulation.traffic import preserve_vehicle_dimensions
from commonroad.geometry.shape import Rectangle
from commonroad.scenario.obstacle import DynamicObstacle, ObstacleType

import simulation.interactive as interactive
from simulation.simulations import SimulationSettings, run_simulation
from test_interactive_sync import _initial, _straight_case, _StraightPlanner


def _parallel_network(directory: Path) -> tuple[Path, Path]:
    """Two nearby legal roads make route-free XY placement choose the wrong road."""
    nodes = directory / "nodes.xml"
    edges = directory / "edges.xml"
    network = directory / "network.net.xml"
    routes = directory / "routes.rou.xml"
    nodes.write_text(
        '<nodes><node id="a0" x="0" y="0"/>'
        '<node id="a1" x="100" y="0"/>'
        '<node id="b0" x="0" y="3.4"/>'
        '<node id="b1" x="100" y="3.4"/></nodes>'
    )
    edges.write_text(
        '<edges><edge id="nearby" from="a0" to="a1" numLanes="1" width="3.2" spreadType="center"/>'
        '<edge id="assigned" from="b0" to="b1" numLanes="1" width="4.2" spreadType="center"/></edges>'
    )
    subprocess.run(
        [
            "netconvert", "--node-files", str(nodes), "--edge-files", str(edges),
            "--offset.disable-normalization", "true", "--output-file", str(network),
        ],
        check=True, capture_output=True, text=True,
    )
    routes.write_text(
        '<routes><vType id="traffic" length="4.5" width="1.8"/>'
        '<route id="intended" edges="assigned"/>'
        '<vehicle id="7" type="traffic" route="intended" depart="0" '
        'departPos="12.25" departSpeed="3"/></routes>'
    )
    return network, routes


def test_exact_background_pose_retains_assigned_nearby_road(tmp_path):
    network, routes = _parallel_network(tmp_path)
    actor = DynamicObstacle(
        7, ObstacleType.CAR, Rectangle(4.5, 1.8),
        _initial([10.0, 1.4], speed=3.0),
    )
    libsumo.start(
        [
            "sumo", "--net-file", str(network), "--route-files", str(routes),
            "--step-length", "0.1", "--lateral-resolution", "1", "--no-step-log", "true",
        ]
    )
    try:
        libsumo.simulationStep()
        assert list(libsumo.vehicle.getRoute("7")) == ["assigned"]
        interactive._place_background_vehicle(actor, actor.initial_state)
        libsumo.simulationStep()
        assert list(libsumo.vehicle.getRoute("7")) == ["assigned"]
        front = np.asarray(libsumo.vehicle.getPosition("7"))
        np.testing.assert_allclose(front - [2.25, 0.0], actor.initial_state.position, atol=1e-9)
        assert libsumo.vehicle.getAngle("7") == pytest.approx(90.0, abs=1e-9)
        assert libsumo.vehicle.getSpeed("7") == pytest.approx(3.0, abs=1e-9)
    finally:
        libsumo.close()
    assert not libsumo.isLoaded()


@pytest.mark.parametrize("birth_step", [0, 2], ids=["initial-traffic", "future-traffic"])
def test_background_birth_preserves_route_state_and_ego_commands(monkeypatch, birth_step):
    scenario, problems = _straight_case(
        traffic=_initial([50.0, 0.0], speed=4.0, step=birth_step),
        ego=_initial([10.0, 0.0], speed=5.0),
    )
    source_actor = scenario.obstacle_by_id(100)
    placements = []
    observations = {}
    original_place = interactive._place_background_vehicle

    def record_placement(actor, state):
        before = list(libsumo.vehicle.getRoute(str(actor.obstacle_id)))
        original_place(actor, state)
        after = list(libsumo.vehicle.getRoute(str(actor.obstacle_id)))
        placements.append((actor.obstacle_id, state.time_step, before, after))

    class ObservedSimulation(interactive.InteractiveSimulation):
        def _post_simulation_step_hook(self, step):
            super()._post_simulation_step_hook(step)
            active = set(libsumo.vehicle.getIDList())
            if step < birth_step:
                assert "100" not in active
            elif step == birth_step:
                assert "100" in active
                state = self._sumo_interface.vehicles._fetch_dynamic_obstacle_state_params_from_sumo_simulation("100")
                observations.update(
                    position=state["position"], orientation=state["orientation"],
                    velocity=state["velocity"], route=list(libsumo.vehicle.getRoute("100")),
                )

    monkeypatch.setattr(interactive, "_place_background_vehicle", record_placement)
    monkeypatch.setattr(
        "simulation.simulations.InteractiveSumoSimulationWithMotionPlanner", ObservedSimulation
    )
    result = run_simulation(
        scenario, problems, _StraightPlanner(),
        settings=SimulationSettings(simulation_steps=4, replanning_interval=1),
    )
    assert not libsumo.isLoaded()
    assert len(placements) == 1
    actor_id, step, before, after = placements[0]
    assert (actor_id, step) == (100, birth_step)
    assert before == after == observations["route"]
    np.testing.assert_allclose(
        observations["position"], source_actor.initial_state.position, atol=1e-9, rtol=0
    )
    assert observations["orientation"] == pytest.approx(source_actor.initial_state.orientation, abs=1e-9)
    assert observations["velocity"] == pytest.approx(source_actor.initial_state.velocity, abs=1e-9)
    assert result.ego_vehicles[10].state_at_time(4) is not None


def test_essen_background_calibration_retains_native_lane_and_complete_route():
    source = ASSETS / "scenarios/public/DEU_EssenCRC26P-60_19700_I-1.xml"
    scenario, _ = CommonRoadFileReader(str(source)).open()
    initial = deepcopy(scenario.obstacle_by_id(30458).initial_state)
    observations = []

    class ObservedSimulation(interactive.InteractiveSimulation):
        def _reached_simulation_end_condition(self, step):
            return step >= 2

        def _post_simulation_step_hook(self, step):
            super()._post_simulation_step_hook(step)
            assert "30458" in libsumo.vehicle.getIDList()
            # getRoadID dereferences a null lane for this native off-network
            # state in SUMO; inspect the safe lane ID before any lane getter.
            lane_id = libsumo.vehicle.getLaneID("30458")
            assert lane_id, "Exact initial calibration left an active actor off-network"
            route = list(libsumo.vehicle.getRoute("30458"))
            assert route == expected_route
            state = self._sumo_interface.vehicles._fetch_dynamic_obstacle_state_params_from_sumo_simulation("30458")
            observations.append((step, lane_id, route, state))

    runner = ObservedSimulation.from_scenario(
        scenario, PlanningProblemSet(),
        simulation_config=InteractiveSumoSimulationWithMotionPlannerConfig(
            random_seed=1234, lateral_resolution=1.0,
        ),
    )
    routes = runner._sumo_project.get_file_path(SumoFileType.VEHICLE_ROUTES)
    preserve_vehicle_dimensions(scenario, routes)
    vehicle = ET.parse(routes).getroot().find("vehicle[@id='30458']")
    expected_route = vehicle.find("route").get("edges").split()
    runner.run(None, max_simulation_steps=2)
    assert not libsumo.isLoaded()
    assert [row[0] for row in observations] == [0, 1, 2]
    native_initial = observations[0][3]
    np.testing.assert_allclose(native_initial["position"], initial.position, atol=1e-9, rtol=0)
    assert native_initial["orientation"] == pytest.approx(initial.orientation, abs=1e-9)
    assert native_initial["velocity"] == pytest.approx(initial.velocity, abs=1e-9)
